# Workspace Hub Manager

Java 21 + JavaFX + MySQL + Maven desktop application for shared-workspace staff.

## Status (Stage 3: new interface on top of MySQL, validation services, SQLite import)

Implemented: dashboard, desks/halls, members, bookings (overlap prevention), power/internet status history.
Not yet implemented (see `TODO.md`): login/roles, subscriptions/payments, cafeteria/stock, reports/CSV, UI redesign.

The app stores data in **MySQL**. Old SQLite data (`C:\Users\<you>\.workspace-hub-manager\workspace-hub.db`) is not read automatically; use the import tool below. The old file is opened read-only and never changed.

## MySQL setup (once)

Run in a MySQL 8 shell as an admin user (change the password!):

```sql
CREATE DATABASE workspace_hub CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'workspace_app'@'localhost' IDENTIFIED BY 'choose-a-strong-password';
GRANT ALL PRIVILEGES ON workspace_hub.* TO 'workspace_app'@'localhost';
```

Then give the app its settings, using ONE of:

1. Copy `config/local.properties.example` to `config/local.properties` and edit it (this file is git-ignored), or
2. Set environment variables `WORKSPACEHUB_DB_URL`, `WORKSPACEHUB_DB_USER`, `WORKSPACEHUB_DB_PASSWORD`.

The schema is created and upgraded automatically on start (`src/main/resources/db/migration`, tracked in table `schema_version`).
On first start with empty tables, clearly labelled sample data is inserted.

## Build, test, run (Windows, IntelliJ terminal)

```bat
mvnw.cmd clean test
mvnw.cmd javafx:run
```

Database tests need a separate, disposable database (ALL its tables are dropped on every test run):

```sql
CREATE DATABASE workspace_hub_test CHARACTER SET utf8mb4;
CREATE USER 'workspace_test'@'localhost' IDENTIFIED BY 'another-password';
GRANT ALL PRIVILEGES ON workspace_hub_test.* TO 'workspace_test'@'localhost';
```

```bat
set WORKSPACEHUB_TEST_DB_URL=jdbc:mysql://localhost:3306/workspace_hub_test?allowPublicKeyRetrieval=true^&useSSL=false
set WORKSPACEHUB_TEST_DB_USER=workspace_test
set WORKSPACEHUB_TEST_DB_PASSWORD=another-password
mvnw.cmd clean test
```

Without these variables the database tests are **skipped** (they do not count as passed).

## IntelliJ IDEA

1. File > Project Structure > SDK: JDK 21.
2. Open `pom.xml` as a project; let Maven import.
3. Run configuration for `com.workspacehub.WorkspaceHubApplication`: use the Maven goal `javafx:run`, and add the environment variables above (or use `config/local.properties`).

## Design notes

- Booking overlap is enforced in the persistence layer: the resource row is locked (`SELECT ... FOR UPDATE`) inside a transaction, then conflicts are checked (`existing.start < new.end AND existing.end > new.start`). Adjacent bookings are allowed. Inactive resources cannot be booked.
- Money is stored as `DECIMAL(12,2)`; no currency is assumed because the report does not specify one.
- Times are stored as local `DATETIME` without time-zone conversion.

## Importing old SQLite data into MySQL

Close the app first, then in the project folder:

```bat
mvnw.cmd compile exec:java "-Dexec.mainClass=com.workspacehub.tools.SqliteImporter" "-Dexec.args=C:\Users\HP\.workspace-hub-manager\workspace-hub.db --replace"
```

- Without `--replace` the tool refuses to run if MySQL already contains rows.
- `--replace` first deletes ALL rows in the MySQL database (including the sample data the app inserted on first start), then imports.
- Everything happens in one transaction: if anything fails, nothing is changed. All ids, prices and times are preserved.
- Prices with more than 2 decimal places are rejected (MySQL would round them); fix them in the old app first.

## Validation

Input rules live in `service/ResourceValidator` and `service/MemberValidator`, `ServiceStatusService` checks power/internet updates, and `BookingService` checks its inputs. The screens call these services, so rules apply no matter which screen saves. Errors carry field names, ready for per-field messages in the Stage 3 UI.

## The interface (Stage 3)

Colours: charcoal `#2C2C2C`, plum `#853953`, deep plum `#612D53`, paper `#F3F4F4` (all defined once at the top of `src/main/resources/styles.css`).

- **Moving wallpaper:** soft plum glows drift slowly behind the pages. The **Motion** switch in the top bar turns it off (a still picture stays). To start with motion off, add `-Dworkspacehub.motion=off` to the VM options.
- **Forms** stay open when something is wrong: each message appears under its own field, and problems such as a booking clash appear in a banner. Nothing the user typed is lost.
- **Tables** have friendly empty states, a Cancel/Edit/Deactivate button per row, and live search (it waits for a short pause in typing).
- **Confirmations** for cancelling a booking and deactivating a desk or hall; short **toast** messages for success.
- **Keyboard:** `Ctrl+1` Overview, `Ctrl+2` Bookings, `Ctrl+3` Desks & halls, `Ctrl+4` Members, `Ctrl+5` Services, `Ctrl+N` new booking, `F5` refresh. Every button shows a visible focus ring.
- **Formats:** dates look like `21 Nov 2026`, times `HH:mm`, amounts have two decimals and no currency symbol (the report names no currency). These do not change with the Windows regional settings.

Code layout: `ui/MainController` is only the shell; each page is its own class (`DashboardScreen`, `BookingsScreen`, `ResourcesScreen`, `MembersScreen`, `ServicesScreen`); shared pieces are `UiKit`, `FormDialog`, `Toast`, `AnimatedBackground`, `Formats`.
