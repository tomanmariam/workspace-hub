# TODO

## First working slice — dashboard and core operations
- [x] Show a dashboard with available desks/halls, today's bookings, and current power/internet status from locally persisted data.
- [x] Add, edit, and deactivate desks and halls, including capacity and daily/monthly prices; show whether each resource is currently available.
- [x] Register and manage member records, with search/filter support.
- [x] Create bookings for a member, resource, and time period; reject overlapping active bookings for the same desk or hall; allow cancellation and booking search.
- [x] Record and update power-source and internet status manually, preserving a timestamped status history.
- [x] Save changes immediately to a relational database (now MySQL; was local SQLite).
- [x] Keep UI, business logic, and database access separated in a maintainable Java/MVC-style structure.

## Follow-on modules from the report
- [ ] Implement manager/receptionist login and role-specific access with hashed passwords.
- [ ] Add daily/monthly subscriptions and record payments.
- [ ] Manage cafeteria items, stock quantities, customer orders, automatic stock reduction, and low-stock alerts.
- [ ] Generate occupancy, peak-hour, booking-revenue, and cafeteria-revenue reports for a selected period.
- [ ] Export reports to CSV.
- [ ] Add automated business-rule and database integration tests, then package a runnable desktop release.

## Stage plan
- [x] Stage 1: MySQL, git-ignored config, versioned migrations, persistence-level overlap locking, deterministic tests.
- [x] Stage 2: SQLite -> MySQL import tool; validation services for resources, members and bookings.
- [x] MainController split into a shell plus one class per page (done in Stage 3). Role checks arrive with login in Stage 4.
- [x] Stage 3: new themed UI, moving wallpaper, per-field validation, empty states, toasts, confirmations, keyboard shortcuts, fixed formats.
- [ ] Still open from the UI wish-list: loading indicators for slow databases (data loads on the UI thread), screen-reader testing, a real contrast audit, saved window size.
- [ ] Stage 4: login/roles, subscriptions/payments, cafeteria/stock, reports/CSV.
