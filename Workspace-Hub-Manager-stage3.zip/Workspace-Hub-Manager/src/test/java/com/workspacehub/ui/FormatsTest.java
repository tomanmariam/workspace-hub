package com.workspacehub.ui;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Locale;

import static org.junit.jupiter.api.Assertions.assertEquals;

/** Screen text must not change with the computer's regional settings. */
class FormatsTest {
    private Locale original;

    @BeforeEach
    void useArabicLocale() {
        original = Locale.getDefault();
        Locale.setDefault(Locale.forLanguageTag("ar-SA"));
    }

    @AfterEach
    void restoreLocale() {
        Locale.setDefault(original);
    }

    @Test
    void datesAndTimesAreStableUnderAnotherLocale() {
        assertEquals("4 Mar 2030 · 09:05", Formats.DATE_TIME.format(LocalDateTime.of(2030, 3, 4, 9, 5)));
        assertEquals("4 Mar 2030", Formats.DATE.format(LocalDate.of(2030, 3, 4)));
        assertEquals("Monday, 4 March 2030", Formats.LONG_DATE.format(LocalDate.of(2030, 3, 4)));
    }

    @Test
    void amountsAlwaysHaveTwoDecimalsAndNoCurrency() {
        assertEquals("8.00", Formats.money(new BigDecimal("8")));
        assertEquals("110.50", Formats.money(new BigDecimal("110.5")));
        assertEquals("1234.00", Formats.money(new BigDecimal("1234")));
    }

    @Test
    void blankTextShowsADashAndStatesAreReadable() {
        assertEquals("—", Formats.dash("  "));
        assertEquals("SOLAR BATTERY", Formats.state("SOLAR_BATTERY"));
    }
}
