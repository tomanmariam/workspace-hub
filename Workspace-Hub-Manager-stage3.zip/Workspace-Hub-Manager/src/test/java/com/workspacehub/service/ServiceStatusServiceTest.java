package com.workspacehub.service;

import com.workspacehub.data.TestDatabase;
import com.workspacehub.data.WorkspaceRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class ServiceStatusServiceTest {
    private WorkspaceRepository repository;
    private ServiceStatusService service;

    @BeforeEach
    void setUp() throws Exception {
        repository = TestDatabase.freshRepository();
        service = new ServiceStatusService(repository);
    }

    @Test
    void validUpdateIsStoredWithTrimmedDetail() throws Exception {
        service.update("POWER", "GENERATOR", "  Backup running  ");
        assertEquals("Backup running", repository.serviceHistory().getFirst().detail());
    }

    @Test
    void stateFromTheOtherServiceIsRejected() {
        assertThrows(ValidationException.class, () -> service.update("INTERNET", "GENERATOR", ""));
        assertThrows(ValidationException.class, () -> service.update("POWER", null, ""));
        assertThrows(ValidationException.class, () -> service.update("WATER", "STABLE", ""));
    }

    @Test
    void tooLongDetailIsAFieldErrorNotADatabaseError() throws Exception {
        ValidationException error = assertThrows(ValidationException.class,
                () -> service.update("POWER", "GRID", "x".repeat(256)));
        assertEquals("detail", error.fieldErrors().keySet().iterator().next());
        assertEquals(0, repository.serviceHistory().size());
    }
}
