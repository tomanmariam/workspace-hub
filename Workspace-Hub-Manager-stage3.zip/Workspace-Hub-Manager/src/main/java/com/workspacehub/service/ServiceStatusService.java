package com.workspacehub.service;

import com.workspacehub.data.WorkspaceRepository;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Validates staff-entered power/internet updates before they are stored in the history. */
public final class ServiceStatusService {
    static final int MAX_DETAIL = 255;
    /** The same choices the status dialog offers. */
    static final Map<String, List<String>> ALLOWED_STATES = Map.of(
            "POWER", List.of("GRID", "GENERATOR", "SOLAR_BATTERY", "OUTAGE"),
            "INTERNET", List.of("STABLE", "SLOW", "DOWN"));

    private final WorkspaceRepository repository;

    public ServiceStatusService(WorkspaceRepository repository) {
        this.repository = repository;
    }

    public void update(String service, String state, String detail) throws SQLException {
        Map<String, String> errors = new LinkedHashMap<>();
        List<String> states = service == null ? null : ALLOWED_STATES.get(service);
        if (states == null) {
            errors.put("service", "Unknown service.");
        } else if (state == null || !states.contains(state)) {
            errors.put("state", "Choose one of the listed statuses.");
        }
        String cleanDetail = detail == null ? "" : detail.trim();
        if (cleanDetail.length() > MAX_DETAIL) {
            errors.put("detail", "Details can be at most " + MAX_DETAIL + " characters.");
        }
        if (!errors.isEmpty()) throw new ValidationException(errors);
        repository.updateServiceStatus(service, state, cleanDetail);
    }
}
