package com.workspacehub.ui;

import com.workspacehub.model.ServiceStatus;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.util.List;

final class ServicesScreen implements Screen {
    private final AppContext ctx;

    ServicesScreen(AppContext ctx) {
        this.ctx = ctx;
    }

    @Override
    public String title() {
        return "Services status";
    }

    @Override
    public String subtitle() {
        return "Power and internet, updated by staff";
    }

    static Label statePill(ServiceStatus status) {
        Label pill = UiKit.label(Formats.state(status.state()), "pill");
        pill.getStyleClass().add(status.state().equals("OUTAGE") || status.state().equals("DOWN") ? "pill-alert" : "pill-ok");
        return pill;
    }

    @Override
    public Node build() throws Exception {
        VBox current = new VBox(12);
        for (ServiceStatus status : ctx.repository.latestServiceStatuses()) {
            Region spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);
            VBox info = new VBox(6, UiKit.label(status.displayName(), "card-title"), statePill(status),
                    UiKit.label((status.detail().isBlank() ? "No notes" : status.detail())
                            + " · last updated " + status.updatedAt().format(Formats.DATE_TIME), "section-caption"));
            HBox row = new HBox(18, info, spacer, UiKit.primary("Update status", () -> update(status)));
            row.setAlignment(Pos.CENTER_LEFT);
            row.getStyleClass().add("service-row");
            current.getChildren().add(row);
        }
        var history = FXCollections.observableArrayList(ctx.repository.serviceHistory());
        TableView<ServiceStatus> table = UiKit.table(history, UiKit.emptyState("No updates yet",
                "Each status change you save is recorded here with the time.", null));
        UiKit.column(table, "Service", ServiceStatus::displayName, 1.0);
        UiKit.column(table, "Status", status -> Formats.state(status.state()), 1.0);
        UiKit.column(table, "Notes", status -> Formats.dash(status.detail()), 1.8);
        UiKit.column(table, "When", status -> status.updatedAt().format(Formats.DATE_TIME), 1.3);
        return new VBox(18,
                UiKit.pageHeading("Services status", "Every change is stored with its time."),
                UiKit.card("Current conditions", "Press “Update status” when something changes.", current),
                UiKit.card("Recent history", "Latest 100 updates", table));
    }

    private void update(ServiceStatus existing) {
        boolean power = existing.service().equals("POWER");
        FormDialog form = new FormDialog(ctx.stage, "Update " + existing.displayName().toLowerCase(), "Save update");
        ComboBox<String> state = form.combo("state", "Status", power
                ? List.of("GRID", "GENERATOR", "SOLAR_BATTERY", "OUTAGE") : List.of("STABLE", "SLOW", "DOWN"), existing.state());
        state.setConverter(new javafx.util.StringConverter<>() {
            @Override public String toString(String value) { return Formats.state(value); }
            @Override public String fromString(String value) { return value; }
        });
        TextField detail = form.text("detail", "Notes (optional)", existing.detail(),
                power ? "Notes about the power source" : "Speed or connection notes");
        form.onSubmit(() -> ctx.serviceStatus.update(existing.service(), state.getValue(), detail.getText()));
        if (form.showAndWait()) {
            ctx.toast.success(existing.displayName() + " status updated.");
            ctx.refresh();
        }
    }
}
