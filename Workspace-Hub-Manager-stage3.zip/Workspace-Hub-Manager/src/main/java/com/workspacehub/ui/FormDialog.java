package com.workspacehub.ui;

import com.workspacehub.data.WorkspaceRepository.BookingConflictException;
import com.workspacehub.service.ValidationException;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Dialog;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Window;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * A form dialog that stays open when something is wrong: each message appears under its own
 * field, and problems that belong to no single field (for example a booking clash) appear in a
 * banner at the top. The user's input is never lost.
 */
final class FormDialog {
    @FunctionalInterface
    interface Submit {
        void run() throws Exception;
    }

    private record Field(Node control, Label error) {
    }

    private final Dialog<ButtonType> dialog = new Dialog<>();
    private final VBox content = new VBox(14);
    private final Label banner = new Label();
    private final Map<String, Field> fields = new LinkedHashMap<>();
    private Submit submit = () -> {
    };
    private Node firstControl;

    FormDialog(Window owner, String title, String submitText) {
        dialog.initOwner(owner);
        dialog.setTitle(title);
        dialog.setHeaderText(null);
        DialogPane pane = dialog.getDialogPane();
        pane.getStylesheets().add(UiKit.stylesheet());
        pane.setPrefWidth(460);
        ButtonType ok = new ButtonType(submitText, ButtonBar.ButtonData.OK_DONE);
        pane.getButtonTypes().addAll(ok, ButtonType.CANCEL);
        Label heading = new Label(title);
        heading.getStyleClass().add("dialog-heading");
        banner.getStyleClass().add("form-banner");
        banner.setWrapText(true);
        banner.setVisible(false);
        banner.setManaged(false);
        content.setPadding(new Insets(8, 6, 4, 6));
        content.getChildren().addAll(heading, banner);
        pane.setContent(content);
        Button okButton = (Button) pane.lookupButton(ok);
        okButton.getStyleClass().add("primary-button");
        ((Button) pane.lookupButton(ButtonType.CANCEL)).getStyleClass().add("secondary-button");
        okButton.addEventFilter(ActionEvent.ACTION, event -> {
            clearErrors();
            try {
                submit.run();
            } catch (ValidationException exception) {
                showFieldErrors(exception.fieldErrors());
                event.consume();
            } catch (BookingConflictException exception) {
                showBanner(exception.getMessage());
                event.consume();
            } catch (SQLException exception) {
                showBanner("Could not save because of a database problem: " + exception.getMessage());
                event.consume();
            } catch (Exception exception) {
                showBanner("Something went wrong: " + exception.getMessage());
                event.consume();
            }
        });
    }

    void onSubmit(Submit action) {
        this.submit = action;
    }

    TextField text(String key, String label, String value, String prompt) {
        TextField field = new TextField(value);
        field.setPromptText(prompt);
        add(key, label, field);
        return field;
    }

    <T> ComboBox<T> combo(String key, String label, List<T> items, T value) {
        ComboBox<T> box = new ComboBox<>(FXCollections.observableArrayList(items));
        box.setValue(value);
        add(key, label, box);
        return box;
    }

    DatePicker date(String key, String label, LocalDate value) {
        DatePicker picker = UiKit.datePicker(value);
        add(key, label, picker);
        return picker;
    }

    void add(String key, String label, Node control) {
        Label caption = new Label(label);
        caption.getStyleClass().add("form-label");
        Label error = new Label();
        error.getStyleClass().add("field-error");
        error.setWrapText(true);
        error.setVisible(false);
        error.setManaged(false);
        if (control instanceof Region region) region.setMaxWidth(Double.MAX_VALUE);
        content.getChildren().add(new VBox(5, caption, control, error));
        fields.put(key, new Field(control, error));
        if (firstControl == null) firstControl = control;
    }

    /** Shows the dialog; true when the form was submitted successfully. */
    boolean showAndWait() {
        Platform.runLater(() -> {
            if (firstControl != null) firstControl.requestFocus();
        });
        return dialog.showAndWait().filter(button -> button.getButtonData() == ButtonBar.ButtonData.OK_DONE).isPresent();
    }

    private void clearErrors() {
        banner.setVisible(false);
        banner.setManaged(false);
        for (Field field : fields.values()) {
            field.error().setVisible(false);
            field.error().setManaged(false);
            field.control().getStyleClass().remove("invalid");
        }
    }

    private void showFieldErrors(Map<String, String> errors) {
        boolean focused = false;
        StringBuilder other = new StringBuilder();
        for (Map.Entry<String, String> entry : errors.entrySet()) {
            Field field = fields.get(entry.getKey());
            if (field == null) {
                other.append(entry.getValue()).append(' ');
                continue;
            }
            field.error().setText(entry.getValue());
            field.error().setVisible(true);
            field.error().setManaged(true);
            field.control().getStyleClass().add("invalid");
            if (!focused) {
                field.control().requestFocus();
                focused = true;
            }
        }
        if (!other.isEmpty()) showBanner(other.toString().trim());
        dialog.getDialogPane().getScene().getWindow().sizeToScene();
    }

    private void showBanner(String message) {
        banner.setText(message);
        banner.setVisible(true);
        banner.setManaged(true);
        dialog.getDialogPane().getScene().getWindow().sizeToScene();
    }
}
