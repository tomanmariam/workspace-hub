package com.workspacehub.ui;

import com.workspacehub.model.Booking;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.time.LocalDate;
import java.util.List;
import java.util.function.Consumer;

final class BookingsScreen implements Screen {
    private final AppContext ctx;

    BookingsScreen(AppContext ctx) {
        this.ctx = ctx;
    }

    @Override
    public String title() {
        return "Bookings";
    }

    @Override
    public String subtitle() {
        return "Reserve time slots without double-booking";
    }

    /** Shared by the dashboard (read only) and this page (with a Cancel button per row). */
    static void addColumns(TableView<Booking> table, boolean withActions, Consumer<Booking> onCancel) {
        UiKit.column(table, "Member", Booking::memberName, 1.2);
        UiKit.column(table, "Desk / hall", Booking::resourceName, 1.1);
        UiKit.column(table, "Starts", booking -> booking.startTime().format(Formats.DATE_TIME), 1.3);
        UiKit.column(table, "Ends", booking -> booking.endTime().format(Formats.DATE_TIME), 1.3);
        UiKit.pillColumn(table, "Status", booking -> booking.status().equals("ACTIVE") ? "Active" : "Cancelled",
                booking -> booking.status().equals("ACTIVE") ? "pill-ok" : "pill-muted", 0.9);
        if (withActions) {
            UiKit.actionColumn(table, booking -> booking.status().equals("ACTIVE")
                    ? List.of(UiKit.small("Cancel booking", () -> onCancel.accept(booking))) : List.<Button>of(), 140);
        }
    }

    @Override
    public Node build() throws Exception {
        DatePicker day = UiKit.datePicker(LocalDate.now());
        TextField search = UiKit.searchField("Search by member, desk or status");
        ObservableList<Booking> items = FXCollections.observableArrayList();
        TableView<Booking> table = UiKit.table(items, UiKit.emptyState("", "", null));
        addColumns(table, true, this::cancel);

        Runnable reload = () -> {
            LocalDate selected = day.getValue() == null ? LocalDate.now() : day.getValue();
            String filter = search.getText() == null ? "" : search.getText().trim();
            try {
                items.setAll(ctx.repository.listBookings(selected, filter));
                table.setPlaceholder(filter.isEmpty()
                        ? UiKit.emptyState("No bookings on " + selected.format(Formats.DATE), "Pick another day or create a booking.",
                                UiKit.primary("+ New booking", () -> { if (BookingDialog.open(ctx, selected)) ctx.refresh(); }))
                        : UiKit.emptyState("No bookings match “" + filter + "”", "Try a different search.", null));
            } catch (Exception exception) {
                ctx.toast.warning("Could not load bookings: " + exception.getMessage());
            }
        };
        UiKit.onTypingPause(search, reload);
        day.setOnAction(event -> reload.run());
        Button today = UiKit.secondary("Today", () -> day.setValue(LocalDate.now()));
        reload.run();

        HBox tools = new HBox(10, day, today, search);
        tools.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
        return new VBox(18,
                UiKit.pageHeading("Bookings", "Times are shown in this computer’s local time.",
                        UiKit.primary("+ New booking", () -> {
                            if (BookingDialog.open(ctx, day.getValue() == null ? LocalDate.now() : day.getValue())) ctx.refresh();
                        })),
                tools, UiKit.card("Booking schedule", null, table));
    }

    private void cancel(Booking booking) {
        if (!UiKit.confirm(ctx.stage, "Cancel this booking?",
                booking.memberName() + " · " + booking.resourceName() + "\n"
                        + booking.startTime().format(Formats.DATE_TIME) + " – " + booking.endTime().format(Formats.TIME)
                        + "\n\nThe time slot becomes available again.", "Cancel booking")) return;
        try {
            ctx.bookings.cancelBooking(booking.id());
            ctx.toast.success("Booking cancelled.");
            ctx.refresh();
        } catch (Exception exception) {
            ctx.toast.warning("Could not cancel the booking: " + exception.getMessage());
        }
    }
}
