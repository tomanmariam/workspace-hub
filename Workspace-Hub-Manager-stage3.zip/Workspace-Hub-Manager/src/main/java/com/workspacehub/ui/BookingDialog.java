package com.workspacehub.ui;

import com.workspacehub.model.Member;
import com.workspacehub.model.Resource;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import com.workspacehub.service.ValidationException;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** The "new booking" form, shared by the dashboard and the bookings page. */
final class BookingDialog {
    private BookingDialog() {
    }

    /** @return true when a booking was created */
    static boolean open(AppContext ctx, LocalDate defaultDay) {
        List<Member> members;
        List<Resource> resources;
        try {
            members = ctx.members.search("");
            resources = ctx.resources.list(false);
        } catch (Exception exception) {
            ctx.toast.warning("Could not prepare the booking form: " + exception.getMessage());
            return false;
        }
        if (members.isEmpty() || resources.isEmpty()) {
            ctx.toast.warning("Add at least one member and one active desk or hall before creating a booking.");
            return false;
        }
        FormDialog form = new FormDialog(ctx.stage, "New booking", "Create booking");
        ComboBox<Member> member = form.combo("member", "Member", members, members.getFirst());
        ComboBox<Resource> resource = form.combo("resource", "Desk or hall", resources, resources.getFirst());
        DatePicker startDate = UiKit.datePicker(defaultDay);
        TextField startTime = new TextField("09:00");
        startTime.setPrefColumnCount(6);
        DatePicker endDate = UiKit.datePicker(defaultDay);
        TextField endTime = new TextField("10:00");
        endTime.setPrefColumnCount(6);
        form.add("start", "Starts (date and 24-hour time)", dateAndTime(startDate, startTime));
        form.add("end", "Ends (date and 24-hour time)", dateAndTime(endDate, endTime));
        form.onSubmit(() -> {
            Map<String, String> errors = new LinkedHashMap<>();
            LocalDateTime from = combine(startDate, startTime, "start", errors);
            LocalDateTime to = combine(endDate, endTime, "end", errors);
            if (!errors.isEmpty()) throw new ValidationException(errors);
            ctx.bookings.createBooking(member.getValue().id(), resource.getValue().id(), from, to);
        });
        boolean created = form.showAndWait();
        if (created) ctx.toast.success("Booking saved. The time slot is reserved.");
        return created;
    }

    private static HBox dateAndTime(DatePicker date, TextField time) {
        HBox box = new HBox(8, date, time);
        HBox.setHgrow(date, Priority.ALWAYS);
        return box;
    }

    private static LocalDateTime combine(DatePicker date, TextField time, String key, Map<String, String> errors) {
        if (date.getValue() == null) {
            errors.put(key, "Choose a date.");
            return null;
        }
        try {
            return LocalDateTime.of(date.getValue(), LocalTime.parse(time.getText().trim(), Formats.TIME));
        } catch (DateTimeParseException exception) {
            errors.put(key, "Write the time as HH:mm, for example 09:30.");
            return null;
        }
    }
}
