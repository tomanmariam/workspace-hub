package com.workspacehub.ui;

import com.workspacehub.model.Resource;
import com.workspacehub.model.ResourceType;
import com.workspacehub.service.ValidationException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

final class ResourcesScreen implements Screen {
    private static final Pattern NUMBER = Pattern.compile("\\d+(\\.\\d+)?");
    private final AppContext ctx;

    ResourcesScreen(AppContext ctx) {
        this.ctx = ctx;
    }

    @Override
    public String title() {
        return "Desks & halls";
    }

    @Override
    public String subtitle() {
        return "Bookable workspace resources and their rates";
    }

    @Override
    public Node build() throws Exception {
        Set<Long> bookedNow = ctx.repository.bookedResourceIdsNow();
        List<Resource> all = ctx.resources.list(true);
        TextField search = UiKit.searchField("Search by name or type");
        CheckBox showInactive = new CheckBox("Show inactive");
        showInactive.setSelected(true);
        ObservableList<Resource> items = FXCollections.observableArrayList();
        TableView<Resource> table = UiKit.table(items, UiKit.emptyState("", "", null));
        UiKit.column(table, "Name", Resource::name, 1.3);
        UiKit.column(table, "Type", resource -> resource.type().label(), 0.8);
        UiKit.column(table, "Capacity", resource -> Integer.toString(resource.capacity()), 0.8);
        UiKit.column(table, "Daily rate", resource -> Formats.money(resource.dailyPrice()), 0.9);
        UiKit.column(table, "Monthly rate", resource -> Formats.money(resource.monthlyPrice()), 1.0);
        UiKit.pillColumn(table, "Availability", resource -> availability(resource, bookedNow),
                resource -> !resource.active() ? "pill-muted" : bookedNow.contains(resource.id()) ? "pill-alert" : "pill-ok", 1.1);
        UiKit.actionColumn(table, resource -> List.of(
                UiKit.small("Edit", () -> edit(resource)),
                UiKit.small(resource.active() ? "Deactivate" : "Activate", () -> toggle(resource))), 190);

        Runnable filter = () -> {
            String text = search.getText() == null ? "" : search.getText().trim().toLowerCase(Locale.ROOT);
            items.setAll(all.stream()
                    .filter(resource -> showInactive.isSelected() || resource.active())
                    .filter(resource -> text.isEmpty() || resource.name().toLowerCase(Locale.ROOT).contains(text)
                            || resource.type().label().toLowerCase(Locale.ROOT).contains(text))
                    .toList());
            table.setPlaceholder(all.isEmpty()
                    ? UiKit.emptyState("No desks or halls yet", "Add a desk or hall so members can book it.",
                            UiKit.primary("+ Add resource", () -> edit(null)))
                    : UiKit.emptyState("Nothing matches", "Change the search or show inactive resources.", null));
        };
        UiKit.onTypingPause(search, filter);
        showInactive.setOnAction(event -> filter.run());
        filter.run();

        HBox tools = new HBox(14, search, showInactive);
        tools.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
        return new VBox(18,
                UiKit.pageHeading("Desks & halls", "Inactive resources stay on record but cannot be booked.",
                        UiKit.primary("+ Add resource", () -> edit(null))),
                tools, UiKit.card("Workspace inventory", null, table));
    }

    private static String availability(Resource resource, Set<Long> bookedNow) {
        if (!resource.active()) return "Inactive";
        return bookedNow.contains(resource.id()) ? "Booked now" : "Available now";
    }

    private void toggle(Resource resource) {
        boolean deactivating = resource.active();
        if (deactivating && !UiKit.confirm(ctx.stage, "Deactivate “" + resource.name() + "”?",
                "It will no longer be bookable. Existing bookings are kept.", "Deactivate")) return;
        try {
            ctx.resources.save(new Resource(resource.id(), resource.name(), resource.type(), resource.capacity(),
                    resource.dailyPrice(), resource.monthlyPrice(), !resource.active()));
            ctx.toast.success(resource.name() + (deactivating ? " deactivated." : " activated."));
            ctx.refresh();
        } catch (Exception exception) {
            ctx.toast.warning("Could not update " + resource.name() + ": " + exception.getMessage());
        }
    }

    private void edit(Resource existing) {
        FormDialog form = new FormDialog(ctx.stage, existing == null ? "Add desk or hall" : "Edit desk or hall", "Save");
        TextField name = form.text("name", "Name", existing == null ? "" : existing.name(), "e.g. Desk A-04");
        ComboBox<ResourceType> type = form.combo("type", "Type", List.of(ResourceType.values()),
                existing == null ? ResourceType.DESK : existing.type());
        TextField capacity = form.text("capacity", "Capacity (people)", existing == null ? "1" : Integer.toString(existing.capacity()), "1");
        TextField daily = form.text("dailyPrice", "Daily rate", existing == null ? "0" : existing.dailyPrice().toPlainString(), "0.00");
        TextField monthly = form.text("monthlyPrice", "Monthly rate", existing == null ? "0" : existing.monthlyPrice().toPlainString(), "0.00");
        form.onSubmit(() -> {
            Map<String, String> errors = new LinkedHashMap<>();
            int seats = 0;
            if (capacity.getText().trim().matches("\\d{1,6}")) seats = Integer.parseInt(capacity.getText().trim());
            else errors.put("capacity", "Enter a whole number, for example 1.");
            BigDecimal dailyRate = money(daily, "dailyPrice", "Daily rate", errors);
            BigDecimal monthlyRate = money(monthly, "monthlyPrice", "Monthly rate", errors);
            if (!errors.isEmpty()) throw new ValidationException(errors);
            ctx.resources.save(new Resource(existing == null ? 0 : existing.id(), name.getText().trim(),
                    type.getValue(), seats, dailyRate, monthlyRate, existing == null || existing.active()));
        });
        if (form.showAndWait()) {
            ctx.toast.success(existing == null ? "Desk or hall added." : "Changes saved.");
            ctx.refresh();
        }
    }

    private static BigDecimal money(TextField field, String key, String label, Map<String, String> errors) {
        String text = field.getText().trim();
        if (!NUMBER.matcher(text).matches()) {
            errors.put(key, label + ": enter a number like 8 or 8.50.");
            return null;
        }
        return new BigDecimal(text);
    }
}
