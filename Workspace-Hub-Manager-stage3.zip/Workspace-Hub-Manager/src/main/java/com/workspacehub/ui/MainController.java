package com.workspacehub.ui;

import com.workspacehub.data.WorkspaceRepository;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ToggleButton;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * The application shell: animated wallpaper, sidebar, top bar and the page area. Each page is a
 * separate {@link Screen}; this class only decides which one is showing.
 */
public final class MainController {
    private final Stage stage;
    private final WorkspaceRepository repository;
    private final AnimatedBackground background = new AnimatedBackground();
    private final Toast toast = new Toast();
    private final VBox page = new VBox(18);
    private final ScrollPane scroll = new ScrollPane(page);
    private final Label titleLabel = new Label();
    private final Label subtitleLabel = new Label();
    private final Map<String, Button> navButtons = new LinkedHashMap<>();
    private final Map<String, Screen> screens = new LinkedHashMap<>();
    private String current = "dashboard";

    public MainController(Stage stage, WorkspaceRepository repository) {
        this.stage = stage;
        this.repository = repository;
    }

    public void show() {
        AppContext ctx = new AppContext(stage, repository, toast, this::navigate, this::refresh);
        screens.put("dashboard", new DashboardScreen(ctx));
        screens.put("resources", new ResourcesScreen(ctx));
        screens.put("bookings", new BookingsScreen(ctx));
        screens.put("members", new MembersScreen(ctx));
        screens.put("services", new ServicesScreen(ctx));
        screens.put("cafeteria", new PlannedScreen("Cafeteria & stock",
                "Inventory, quantities and low-stock warnings."));
        screens.put("reports", new PlannedScreen("Reports",
                "Summaries of bookings and usage, with CSV export."));

        page.getStyleClass().add("page-content");
        page.setPadding(new Insets(26, 32, 36, 32));
        scroll.setFitToWidth(true);
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scroll.getStyleClass().add("content-scroll");

        BorderPane shell = new BorderPane();
        shell.setLeft(buildSidebar());
        BorderPane main = new BorderPane();
        main.setTop(buildTopbar());
        main.setCenter(scroll);
        shell.setCenter(main);

        StackPane root = new StackPane(background, shell, toast);
        root.getStyleClass().add("app-root");
        StackPane.setAlignment(toast, Pos.BOTTOM_RIGHT);
        toast.setMaxSize(Region.USE_PREF_SIZE, Region.USE_PREF_SIZE);

        Scene scene = new Scene(root, 1380, 880);
        scene.getStylesheets().add(UiKit.stylesheet());
        addShortcuts(scene, ctx);
        stage.setTitle("Workspace Hub Manager");
        stage.setMinWidth(1120);
        stage.setMinHeight(720);
        stage.setScene(scene);
        stage.show();
        root.setFocusTraversable(true);
        root.requestFocus();
        background.setRunning(!"off".equalsIgnoreCase(System.getProperty("workspacehub.motion", "on")));
        navigate("dashboard");
    }

    /** Opens a page by key: dashboard, resources, bookings, members, services, cafeteria or reports. */
    public void navigate(String key) {
        Screen screen = screens.get(key);
        if (screen == null) return;
        current = key;
        titleLabel.setText(screen.title());
        subtitleLabel.setText(screen.subtitle());
        navButtons.forEach((name, button) -> {
            button.getStyleClass().remove("nav-button-selected");
            if (name.equals(key)) button.getStyleClass().add("nav-button-selected");
        });
        render(screen);
    }

    private void refresh() {
        render(screens.get(current));
    }

    private void render(Screen screen) {
        double position = scroll.getVvalue();
        try {
            page.getChildren().setAll(screen.build());
        } catch (Exception exception) {
            Button retry = UiKit.primary("Try again", this::refresh);
            page.getChildren().setAll(UiKit.card("This page could not be loaded",
                    "Check that MySQL is running and the settings are correct, then try again.",
                    new VBox(12, UiKit.label(String.valueOf(exception.getMessage()), "field-error"), retry)));
        }
        scroll.setVvalue(position);
    }

    private void addShortcuts(Scene scene, AppContext ctx) {
        String[] keys = {"dashboard", "bookings", "resources", "members", "services"};
        KeyCode[] codes = {KeyCode.DIGIT1, KeyCode.DIGIT2, KeyCode.DIGIT3, KeyCode.DIGIT4, KeyCode.DIGIT5};
        for (int i = 0; i < keys.length; i++) {
            String key = keys[i];
            scene.getAccelerators().put(new KeyCodeCombination(codes[i], KeyCombination.SHORTCUT_DOWN), () -> navigate(key));
        }
        scene.getAccelerators().put(new KeyCodeCombination(KeyCode.F5), this::refresh);
        scene.getAccelerators().put(new KeyCodeCombination(KeyCode.N, KeyCombination.SHORTCUT_DOWN), () -> {
            if (BookingDialog.open(ctx, LocalDate.now())) refresh();
        });
    }

    private Node buildTopbar() {
        titleLabel.getStyleClass().add("topbar-title");
        subtitleLabel.getStyleClass().add("topbar-subtitle");
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        ToggleButton motion = new ToggleButton();
        motion.getStyleClass().add("motion-toggle");
        motion.setSelected(!"off".equalsIgnoreCase(System.getProperty("workspacehub.motion", "on")));
        Runnable sync = () -> motion.setText(motion.isSelected() ? "Motion: on" : "Motion: off");
        sync.run();
        motion.setOnAction(event -> {
            background.setRunning(motion.isSelected());
            sync.run();
        });
        motion.setAccessibleText("Turn the moving background on or off");
        Label date = UiKit.label(LocalDate.now().format(Formats.LONG_DATE), "date-chip");
        HBox top = new HBox(14, new VBox(3, titleLabel, subtitleLabel), spacer, motion, date);
        top.setAlignment(Pos.CENTER_LEFT);
        top.setPadding(new Insets(14, 32, 14, 32));
        top.getStyleClass().add("topbar");
        return top;
    }

    private Node buildSidebar() {
        VBox sidebar = new VBox(6);
        sidebar.setPadding(new Insets(24, 16, 20, 16));
        sidebar.setPrefWidth(244);
        sidebar.getStyleClass().add("sidebar");
        Label mark = UiKit.label("W", "brand-mark");
        mark.setAlignment(Pos.CENTER);
        HBox brand = new HBox(11, mark, UiKit.label("Workspace Hub", "brand-name"));
        brand.setAlignment(Pos.CENTER_LEFT);
        sidebar.getChildren().addAll(brand, gap(14), UiKit.label("MANAGEMENT", "sidebar-caption"));
        sidebar.getChildren().addAll(nav("dashboard", "Overview", "Ctrl+1"), nav("bookings", "Bookings", "Ctrl+2"),
                nav("resources", "Desks & halls", "Ctrl+3"), nav("members", "Members", "Ctrl+4"),
                nav("services", "Services status", "Ctrl+5"));
        sidebar.getChildren().addAll(gap(16), UiKit.label("COMING LATER", "sidebar-caption"),
                nav("cafeteria", "Cafeteria & stock", null), nav("reports", "Reports", null));
        Region grow = new Region();
        VBox.setVgrow(grow, Priority.ALWAYS);
        sidebar.getChildren().addAll(grow, UiKit.label("F5 refresh  ·  Ctrl+N new booking", "sidebar-footer"));
        return sidebar;
    }

    private Button nav(String key, String text, String shortcut) {
        Button button = new Button(text);
        button.setMaxWidth(Double.MAX_VALUE);
        button.setAlignment(Pos.CENTER_LEFT);
        button.getStyleClass().add("nav-button");
        button.setOnAction(event -> navigate(key));
        button.setAccessibleText(shortcut == null ? text : text + ", shortcut " + shortcut);
        navButtons.put(key, button);
        return button;
    }

    private static Node gap(double height) {
        Region region = new Region();
        region.setMinHeight(height);
        return region;
    }
}
