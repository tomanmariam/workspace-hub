package com.workspacehub.ui;

import javafx.scene.Node;
import javafx.scene.layout.VBox;

/** Honest placeholder for modules that are not built yet. */
final class PlannedScreen implements Screen {
    private final String title;
    private final String detail;

    PlannedScreen(String title, String detail) {
        this.title = title;
        this.detail = detail;
    }

    @Override
    public String title() {
        return title;
    }

    @Override
    public String subtitle() {
        return "Not built yet";
    }

    @Override
    public Node build() {
        return new VBox(18, UiKit.pageHeading(title, "This module is planned for a later stage."),
                UiKit.card("What is planned", null, UiKit.label(detail, "section-caption")));
    }
}
