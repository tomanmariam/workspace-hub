package com.workspacehub.ui;

import javafx.animation.AnimationTimer;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.RadialGradient;
import javafx.scene.paint.Stop;

/**
 * The slowly moving wallpaper: soft plum glows drifting over charcoal. It can be paused
 * (a static frame is drawn) for people who dislike motion or on slow computers.
 */
final class AnimatedBackground extends Pane {
    private record Glow(Color color, double radius, double speedX, double speedY, double phaseX, double phaseY) {
    }

    private static final Color BASE = Color.web("#2C2C2C");
    private static final Glow[] GLOWS = {
            new Glow(Color.web("#853953"), 0.55, 0.045, 0.060, 0.0, 1.3),
            new Glow(Color.web("#612D53"), 0.65, 0.055, 0.040, 2.1, 0.4),
            new Glow(Color.web("#853953"), 0.40, 0.070, 0.050, 4.0, 3.2),
            new Glow(Color.web("#F3F4F4"), 0.30, 0.035, 0.045, 1.0, 5.1)
    };

    private final Canvas canvas = new Canvas();
    private final AnimationTimer timer;
    private double seconds;
    private long lastFrame;
    private boolean running;

    AnimatedBackground() {
        setMouseTransparent(true);
        getChildren().add(canvas);
        canvas.widthProperty().bind(widthProperty());
        canvas.heightProperty().bind(heightProperty());
        widthProperty().addListener((observable, old, value) -> draw());
        heightProperty().addListener((observable, old, value) -> draw());
        timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                if (lastFrame == 0) lastFrame = now;
                if (now - lastFrame < 33_000_000L) return; // about 30 frames per second is plenty
                seconds += (now - lastFrame) / 1e9;
                lastFrame = now;
                draw();
            }
        };
    }

    boolean isRunning() {
        return running;
    }

    void setRunning(boolean value) {
        running = value;
        lastFrame = 0;
        if (value) timer.start();
        else timer.stop();
        draw();
    }

    private void draw() {
        double w = getWidth();
        double h = getHeight();
        if (w <= 0 || h <= 0) return;
        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.setFill(BASE);
        gc.fillRect(0, 0, w, h);
        double size = Math.max(w, h);
        for (Glow glow : GLOWS) {
            double cx = w * (0.5 + 0.42 * Math.sin(seconds * glow.speedX() * Math.PI * 2 + glow.phaseX()));
            double cy = h * (0.5 + 0.42 * Math.cos(seconds * glow.speedY() * Math.PI * 2 + glow.phaseY()));
            double alpha = glow.color().equals(Color.web("#F3F4F4")) ? 0.07 : 0.85;
            gc.setFill(new RadialGradient(0, 0, cx, cy, size * glow.radius(), false, CycleMethod.NO_CYCLE,
                    new Stop(0, glow.color().deriveColor(0, 1, 1, alpha)),
                    new Stop(1, glow.color().deriveColor(0, 1, 1, 0))));
            gc.fillRect(0, 0, w, h);
        }
    }
}
