package com.workspacehub.ui;

import javafx.scene.Node;

/** One page of the app. {@link #build()} reads fresh data each time it is called. */
interface Screen {
    String title();

    String subtitle();

    Node build() throws Exception;
}
