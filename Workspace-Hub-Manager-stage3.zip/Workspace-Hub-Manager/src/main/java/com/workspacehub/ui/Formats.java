package com.workspacehub.ui;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 * One place for how dates, times and amounts look on screen. Patterns use a fixed locale so the
 * text is the same on every Windows regional setting. No currency symbol is shown because the
 * project report does not name a currency.
 */
public final class Formats {
    private static final Locale LOCALE = Locale.ENGLISH;
    public static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm", LOCALE);
    public static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("d MMM yyyy", LOCALE);
    public static final DateTimeFormatter DATE_TIME = DateTimeFormatter.ofPattern("d MMM yyyy · HH:mm", LOCALE);
    public static final DateTimeFormatter LONG_DATE = DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", LOCALE);

    private Formats() {
    }

    public static String money(BigDecimal value) {
        return value.setScale(2, RoundingMode.HALF_UP).toPlainString();
    }

    public static String dash(String value) {
        return value == null || value.isBlank() ? "—" : value;
    }

    public static String state(String value) {
        return value == null ? "" : value.replace('_', ' ');
    }
}
