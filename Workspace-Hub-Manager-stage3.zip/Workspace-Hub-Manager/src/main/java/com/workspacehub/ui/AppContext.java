package com.workspacehub.ui;

import com.workspacehub.data.WorkspaceRepository;
import com.workspacehub.service.BookingService;
import com.workspacehub.service.MemberService;
import com.workspacehub.service.ResourceService;
import com.workspacehub.service.ServiceStatusService;
import javafx.stage.Stage;

import java.util.function.Consumer;

/** Everything a screen needs, passed in once instead of each screen reaching for globals. */
final class AppContext {
    final Stage stage;
    final WorkspaceRepository repository;
    final BookingService bookings;
    final ResourceService resources;
    final MemberService members;
    final ServiceStatusService serviceStatus;
    final Toast toast;
    private final Consumer<String> navigator;
    private final Runnable refresher;

    AppContext(Stage stage, WorkspaceRepository repository, Toast toast,
               Consumer<String> navigator, Runnable refresher) {
        this.stage = stage;
        this.repository = repository;
        this.bookings = new BookingService(repository);
        this.resources = new ResourceService(repository);
        this.members = new MemberService(repository);
        this.serviceStatus = new ServiceStatusService(repository);
        this.toast = toast;
        this.navigator = navigator;
        this.refresher = refresher;
    }

    void navigate(String key) {
        navigator.accept(key);
    }

    /** Rebuilds the current screen, for example after a save. */
    void refresh() {
        refresher.run();
    }
}
