package com.workspacehub.ui;

import com.workspacehub.model.Member;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.time.LocalDate;
import java.util.List;

final class MembersScreen implements Screen {
    private final AppContext ctx;

    MembersScreen(AppContext ctx) {
        this.ctx = ctx;
    }

    @Override
    public String title() {
        return "Members";
    }

    @Override
    public String subtitle() {
        return "Contact details for everyone who uses the workspace";
    }

    @Override
    public Node build() throws Exception {
        TextField search = UiKit.searchField("Search by name, phone or email");
        ObservableList<Member> items = FXCollections.observableArrayList();
        TableView<Member> table = UiKit.table(items, UiKit.emptyState("", "", null));
        UiKit.column(table, "Name", Member::fullName, 1.3);
        UiKit.column(table, "Phone", member -> Formats.dash(member.phone()), 1.0);
        UiKit.column(table, "Email", member -> Formats.dash(member.email()), 1.5);
        UiKit.column(table, "Joined", member -> member.joinDate().format(Formats.DATE), 0.9);
        UiKit.actionColumn(table, member -> List.of(UiKit.small("Edit", () -> edit(member))), 90);

        Runnable reload = () -> {
            String filter = search.getText() == null ? "" : search.getText().trim();
            try {
                items.setAll(ctx.members.search(filter));
                table.setPlaceholder(filter.isEmpty()
                        ? UiKit.emptyState("No members yet", "Add your first member to start taking bookings.",
                                UiKit.primary("+ Add member", () -> edit(null)))
                        : UiKit.emptyState("No members match “" + filter + "”", "Try a different name, phone or email.", null));
            } catch (Exception exception) {
                ctx.toast.warning("Could not load members: " + exception.getMessage());
            }
        };
        UiKit.onTypingPause(search, reload);
        reload.run();

        HBox tools = new HBox(10, search);
        return new VBox(18,
                UiKit.pageHeading("Members", "Keep contact records together and searchable.",
                        UiKit.primary("+ Add member", () -> edit(null))),
                tools, UiKit.card("Member directory", null, table));
    }

    private void edit(Member existing) {
        FormDialog form = new FormDialog(ctx.stage, existing == null ? "Add member" : "Edit member", "Save");
        TextField name = form.text("fullName", "Full name", existing == null ? "" : existing.fullName(), "e.g. Lina Haddad");
        TextField phone = form.text("phone", "Phone (optional)", existing == null ? "" : existing.phone(), "e.g. +970 59 000 0000");
        TextField email = form.text("email", "Email (optional)", existing == null ? "" : existing.email(), "name@example.com");
        form.onSubmit(() -> ctx.members.save(new Member(existing == null ? 0 : existing.id(),
                name.getText().trim(), phone.getText().trim(), email.getText().trim(),
                existing == null ? LocalDate.now() : existing.joinDate())));
        if (form.showAndWait()) {
            ctx.toast.success(existing == null ? "Member added." : "Member updated.");
            ctx.refresh();
        }
    }
}
