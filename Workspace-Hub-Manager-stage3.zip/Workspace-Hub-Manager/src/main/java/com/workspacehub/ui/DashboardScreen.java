package com.workspacehub.ui;

import com.workspacehub.model.Booking;
import com.workspacehub.model.ServiceStatus;
import javafx.collections.FXCollections;
import javafx.scene.Node;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

import java.time.LocalDate;

final class DashboardScreen implements Screen {
    private final AppContext ctx;

    DashboardScreen(AppContext ctx) {
        this.ctx = ctx;
    }

    @Override
    public String title() {
        return "Dashboard";
    }

    @Override
    public String subtitle() {
        return "Availability, today’s bookings and service status";
    }

    @Override
    public Node build() throws Exception {
        LocalDate today = LocalDate.now();
        HBox metrics = new HBox(14,
                metric("Available now", ctx.repository.countAvailableNow(), "active desks and halls free right now"),
                metric("Bookings today", ctx.repository.countBookingsOn(today), "scheduled for today"),
                metric("Active resources", ctx.repository.countActiveResources(), "desks and halls that can be booked"),
                metric("Members", ctx.repository.countMembers(), "registered in this workspace"));

        HBox services = new HBox(14);
        for (ServiceStatus status : ctx.repository.latestServiceStatuses()) {
            VBox card = new VBox(6, UiKit.label(status.displayName(), "card-title"),
                    ServicesScreen.statePill(status),
                    UiKit.label((status.detail().isBlank() ? "" : status.detail() + " · ")
                            + "updated " + status.updatedAt().format(Formats.DATE_TIME), "section-caption"));
            card.getStyleClass().add("service-card");
            HBox.setHgrow(card, Priority.ALWAYS);
            services.getChildren().add(card);
        }

        var bookings = FXCollections.observableArrayList(ctx.repository.listBookings(today, ""));
        TableView<Booking> table = UiKit.table(bookings, UiKit.emptyState("No bookings today",
                "Create a booking to reserve a desk or hall.",
                UiKit.primary("+ New booking", () -> { if (BookingDialog.open(ctx, today)) ctx.refresh(); })));
        BookingsScreen.addColumns(table, false, null);

        VBox page = new VBox(18,
                UiKit.pageHeading("Overview", "A clear view of availability, bookings and essential services.",
                        UiKit.primary("+ New booking", () -> { if (BookingDialog.open(ctx, today)) ctx.refresh(); })),
                metrics, services,
                UiKit.card("Today’s bookings", Formats.LONG_DATE.format(today), table));
        return page;
    }

    private static Node metric(String title, long value, String caption) {
        VBox card = new VBox(6, UiKit.label(title.toUpperCase(), "metric-eyebrow"),
                UiKit.label(Long.toString(value), "metric-number"), UiKit.label(caption, "metric-caption"));
        card.getStyleClass().add("metric-card");
        HBox.setHgrow(card, Priority.ALWAYS);
        card.setMaxWidth(Double.MAX_VALUE);
        return card;
    }
}
