package com.workspacehub.ui;

import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.animation.SequentialTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

/** Short, non-blocking messages in the bottom-right corner. Success never needs a click to dismiss. */
final class Toast extends VBox {
    Toast() {
        super(8);
        setAlignment(Pos.BOTTOM_RIGHT);
        setPickOnBounds(false);
        setMouseTransparent(true);
        setPadding(new Insets(0, 28, 26, 0));
    }

    void success(String message) {
        show(message, "toast-success", 3500);
    }

    void warning(String message) {
        show(message, "toast-warning", 6000);
    }

    private void show(String message, String style, int millis) {
        Label label = new Label(message);
        label.setWrapText(true);
        label.setMaxWidth(380);
        label.getStyleClass().addAll("toast", style);
        label.setOpacity(0);
        getChildren().add(label);
        FadeTransition in = new FadeTransition(Duration.millis(180), label);
        in.setToValue(1);
        PauseTransition stay = new PauseTransition(Duration.millis(millis));
        FadeTransition out = new FadeTransition(Duration.millis(350), label);
        out.setToValue(0);
        SequentialTransition sequence = new SequentialTransition(in, stay, out);
        sequence.setOnFinished(event -> getChildren().remove(label));
        sequence.play();
    }
}
