package com.workspacehub.ui;

import javafx.animation.PauseTransition;
import javafx.beans.binding.Bindings;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Window;
import javafx.util.Duration;
import javafx.util.StringConverter;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.function.Function;

/** Small reusable building blocks so every screen looks and behaves the same. */
final class UiKit {
    static final double ROW = 44;

    private UiKit() {
    }

    static String stylesheet() {
        return UiKit.class.getResource("/styles.css").toExternalForm();
    }

    static Button primary(String text, Runnable action) {
        return button(text, "primary-button", action);
    }

    static Button secondary(String text, Runnable action) {
        return button(text, "secondary-button", action);
    }

    static Button small(String text, Runnable action) {
        Button button = button(text, "secondary-button", action);
        button.getStyleClass().add("small-button");
        return button;
    }

    private static Button button(String text, String style, Runnable action) {
        Button button = new Button(text);
        button.getStyleClass().add(style);
        button.setOnAction(event -> action.run());
        return button;
    }

    static Label label(String text, String style) {
        Label label = new Label(text);
        label.getStyleClass().add(style);
        return label;
    }

    /** A date picker that always shows dates as "21 Nov 2026", whatever the Windows regional settings. */
    static DatePicker datePicker(LocalDate value) {
        DatePicker picker = new DatePicker(value);
        picker.setPromptText("e.g. 21 Nov 2026");
        picker.setConverter(new StringConverter<>() {
            @Override
            public String toString(LocalDate date) {
                return date == null ? "" : Formats.DATE.format(date);
            }

            @Override
            public LocalDate fromString(String text) {
                try {
                    return text == null || text.isBlank() ? null : LocalDate.parse(text.trim(), Formats.DATE);
                } catch (DateTimeParseException exception) {
                    return null;
                }
            }
        });
        return picker;
    }

    static TextField searchField(String prompt) {
        TextField field = new TextField();
        field.setPromptText(prompt);
        field.getStyleClass().add("search-field");
        HBox.setHgrow(field, Priority.ALWAYS);
        return field;
    }

    /** Runs the action shortly after the user stops typing, so each keystroke does not hit the database. */
    static void onTypingPause(TextField field, Runnable action) {
        PauseTransition pause = new PauseTransition(Duration.millis(250));
        pause.setOnFinished(event -> action.run());
        field.textProperty().addListener((observable, old, value) -> pause.playFromStart());
    }

    static VBox pageHeading(String title, String subtitle, Node... actions) {
        HBox line = new HBox(14);
        line.setAlignment(Pos.CENTER_LEFT);
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        line.getChildren().addAll(label(title, "page-title"), spacer);
        line.getChildren().addAll(actions);
        return new VBox(5, line, label(subtitle, "page-subtitle"));
    }

    static VBox card(String title, String caption, Node content) {
        VBox card = new VBox(14);
        card.getStyleClass().add("surface-card");
        VBox head = new VBox(3, label(title, "card-title"));
        if (caption != null && !caption.isBlank()) head.getChildren().add(label(caption, "section-caption"));
        card.getChildren().addAll(head, content);
        return card;
    }

    static VBox emptyState(String title, String hint, Button action) {
        VBox box = new VBox(8, label(title, "empty-title"), label(hint, "empty-hint"));
        box.setAlignment(Pos.CENTER);
        box.setPadding(new Insets(22));
        if (action != null) box.getChildren().add(action);
        return box;
    }

    /** A table sized to its rows (no blank stripes) with a friendly message when it has no rows. */
    static <T> TableView<T> table(ObservableList<T> items, Node placeholder) {
        TableView<T> table = new TableView<>(items);
        table.getStyleClass().add("data-table");
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        table.setFixedCellSize(ROW);
        table.setPlaceholder(placeholder);
        table.prefHeightProperty().bind(Bindings.createDoubleBinding(
                () -> (items.isEmpty() ? 4 : items.size()) * ROW + ROW + 4, items));
        table.setMinHeight(Region.USE_PREF_SIZE);
        table.setMaxHeight(Region.USE_PREF_SIZE);
        return table;
    }

    static <T> void column(TableView<T> table, String title, Function<T, String> text, double grow) {
        TableColumn<T, String> column = new TableColumn<>(title);
        column.setCellValueFactory(value -> new ReadOnlyStringWrapper(text.apply(value.getValue())));
        column.setPrefWidth(120 * grow);
        column.setMinWidth(Math.max(90, 110 * grow)); // keeps names and dates from being cut off
        table.getColumns().add(column);
    }

    /** A column whose text is drawn as a small coloured pill. */
    static <T> void pillColumn(TableView<T> table, String title, Function<T, String> text,
                               Function<T, String> style, double grow) {
        TableColumn<T, T> column = new TableColumn<>(title);
        column.setCellValueFactory(value -> new ReadOnlyObjectWrapper<>(value.getValue()));
        column.setPrefWidth(120 * grow);
        column.setMinWidth(150); // wide enough for "Available now"
        column.setCellFactory(ignored -> new TableCell<>() {
            @Override
            protected void updateItem(T item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setGraphic(null);
                    return;
                }
                Label pill = label(text.apply(item), "pill");
                pill.getStyleClass().add(style.apply(item));
                setGraphic(pill);
            }
        });
        table.getColumns().add(column);
    }

    /** A column with per-row buttons (for example Edit, Deactivate). */
    static <T> void actionColumn(TableView<T> table, Function<T, List<Button>> buttons, double width) {
        TableColumn<T, T> column = new TableColumn<>("Actions");
        column.setCellValueFactory(value -> new ReadOnlyObjectWrapper<>(value.getValue()));
        column.setPrefWidth(width);
        column.setMinWidth(width);
        column.setSortable(false);
        column.setCellFactory(ignored -> new TableCell<>() {
            @Override
            protected void updateItem(T item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setGraphic(null);
                    return;
                }
                HBox box = new HBox(8);
                box.setAlignment(Pos.CENTER_LEFT);
                box.getChildren().addAll(buttons.apply(item));
                setGraphic(box);
            }
        });
        table.getColumns().add(column);
    }

    static boolean confirm(Window owner, String title, String message, String confirmText) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, message,
                new ButtonType(confirmText, javafx.scene.control.ButtonBar.ButtonData.OK_DONE), ButtonType.CANCEL);
        alert.initOwner(owner);
        alert.setTitle("Workspace Hub Manager");
        alert.setHeaderText(title);
        alert.getDialogPane().getStylesheets().add(stylesheet());
        return alert.showAndWait().filter(button -> button.getButtonData() == javafx.scene.control.ButtonBar.ButtonData.OK_DONE).isPresent();
    }
}
