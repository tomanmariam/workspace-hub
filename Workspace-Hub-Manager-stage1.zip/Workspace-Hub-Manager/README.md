# Workspace Hub Manager

Java 21 + JavaFX + MySQL + Maven desktop application for shared-workspace staff.

## Status (Stage 1: build, configuration, MySQL)

Implemented: dashboard, desks/halls, members, bookings (overlap prevention), power/internet status history.
Not yet implemented (see `TODO.md`): login/roles, subscriptions/payments, cafeteria/stock, reports/CSV, SQLite->MySQL import tool, UI redesign.

The app now stores data in **MySQL**. Previous SQLite files (`~/.workspace-hub-manager/workspace-hub.db`) are NOT read automatically; an import tool is planned for Stage 2. Your old file is left untouched.

## MySQL setup (once)

Run in a MySQL 8 shell as an admin user (change the password!):

```sql
CREATE DATABASE workspace_hub CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'workspace_app'@'localhost' IDENTIFIED BY 'choose-a-strong-password';
GRANT ALL PRIVILEGES ON workspace_hub.* TO 'workspace_app'@'localhost';
```

Then give the app its settings, using ONE of:

1. Copy `config/local.properties.example` to `config/local.properties` and edit it (this file is git-ignored), or
2. Set environment variables `WORKSPACEHUB_DB_URL`, `WORKSPACEHUB_DB_USER`, `WORKSPACEHUB_DB_PASSWORD`.

The schema is created and upgraded automatically on start (`src/main/resources/db/migration`, tracked in table `schema_version`).
On first start with empty tables, clearly labelled sample data is inserted.

## Build, test, run (Windows, IntelliJ terminal)

```bat
mvnw.cmd clean test
mvnw.cmd javafx:run
```

Database tests need a separate, disposable database (ALL its tables are dropped on every test run):

```sql
CREATE DATABASE workspace_hub_test CHARACTER SET utf8mb4;
CREATE USER 'workspace_test'@'localhost' IDENTIFIED BY 'another-password';
GRANT ALL PRIVILEGES ON workspace_hub_test.* TO 'workspace_test'@'localhost';
```

```bat
set WORKSPACEHUB_TEST_DB_URL=jdbc:mysql://localhost:3306/workspace_hub_test?allowPublicKeyRetrieval=true^&useSSL=false
set WORKSPACEHUB_TEST_DB_USER=workspace_test
set WORKSPACEHUB_TEST_DB_PASSWORD=another-password
mvnw.cmd clean test
```

Without these variables the database tests are **skipped** (they do not count as passed).

## IntelliJ IDEA

1. File > Project Structure > SDK: JDK 21.
2. Open `pom.xml` as a project; let Maven import.
3. Run configuration for `com.workspacehub.WorkspaceHubApplication`: use the Maven goal `javafx:run`, and add the environment variables above (or use `config/local.properties`).

## Design notes

- Booking overlap is enforced in the persistence layer: the resource row is locked (`SELECT ... FOR UPDATE`) inside a transaction, then conflicts are checked (`existing.start < new.end AND existing.end > new.start`). Adjacent bookings are allowed. Inactive resources cannot be booked.
- Money is stored as `DECIMAL(12,2)`; no currency is assumed because the report does not specify one.
- Times are stored as local `DATETIME` without time-zone conversion.
