package com.workspacehub.service;

import com.workspacehub.data.WorkspaceRepository;
import com.workspacehub.model.Resource;

import java.sql.SQLException;
import java.util.List;

public final class ResourceService {
    private final WorkspaceRepository repository;

    public ResourceService(WorkspaceRepository repository) {
        this.repository = repository;
    }

    public List<Resource> list(boolean includeInactive) throws SQLException {
        return repository.listResources(includeInactive);
    }

    /** Validates, then saves. Throws {@link ValidationException} for bad input or a duplicate name. */
    public void save(Resource resource) throws SQLException {
        ResourceValidator.validate(resource);
        try {
            repository.saveResource(resource);
        } catch (SQLException exception) {
            if (DuplicateKeys.isDuplicate(exception)) {
                throw new ValidationException("name", "A desk or hall with this name already exists.");
            }
            throw exception;
        }
    }
}
