package com.workspacehub.service;

import com.workspacehub.data.WorkspaceRepository;
import com.workspacehub.model.Member;

import java.sql.SQLException;
import java.util.List;

public final class MemberService {
    private final WorkspaceRepository repository;

    public MemberService(WorkspaceRepository repository) {
        this.repository = repository;
    }

    public List<Member> search(String text) throws SQLException {
        return repository.searchMembers(text);
    }

    /** Validates, then saves. Throws {@link ValidationException} for bad input. */
    public void save(Member member) throws SQLException {
        MemberValidator.validate(member);
        repository.saveMember(member);
    }
}
