package com.workspacehub.service;

import java.sql.SQLException;

final class DuplicateKeys {
    private DuplicateKeys() {
    }

    /** MySQL reports unique-constraint violations as SQLState 23000 with vendor code 1062. */
    static boolean isDuplicate(SQLException exception) {
        for (Throwable t = exception; t != null; t = t.getCause()) {
            if (t instanceof SQLException sql && sql.getErrorCode() == 1062) return true;
        }
        return false;
    }
}
