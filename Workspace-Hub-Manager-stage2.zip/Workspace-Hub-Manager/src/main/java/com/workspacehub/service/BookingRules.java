package com.workspacehub.service;

import java.time.LocalDateTime;
import java.util.Objects;

public final class BookingRules {
    private BookingRules() {
    }

    public static void validateInterval(LocalDateTime start, LocalDateTime end) {
        Objects.requireNonNull(start, "start");
        Objects.requireNonNull(end, "end");
        if (!end.isAfter(start)) {
            throw new IllegalArgumentException("The end time must be later than the start time.");
        }
    }

    /** Half-open time intervals: a booking ending at another's start does not conflict. */
    public static boolean overlaps(LocalDateTime startA, LocalDateTime endA,
                                   LocalDateTime startB, LocalDateTime endB) {
        validateInterval(startA, endA);
        validateInterval(startB, endB);
        return startA.isBefore(endB) && endA.isAfter(startB);
    }
}
