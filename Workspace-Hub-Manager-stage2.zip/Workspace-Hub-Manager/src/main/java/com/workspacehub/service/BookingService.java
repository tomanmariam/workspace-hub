package com.workspacehub.service;

import com.workspacehub.data.WorkspaceRepository;
import com.workspacehub.data.WorkspaceRepository.BookingConflictException;
import com.workspacehub.model.Booking;

import java.sql.SQLException;
import java.time.LocalDateTime;

public final class BookingService {
    private final WorkspaceRepository repository;

    public BookingService(WorkspaceRepository repository) {
        this.repository = repository;
    }

    /**
     * @throws ValidationException      missing member/resource, bad times, or an unavailable resource
     * @throws BookingConflictException the desk or hall is already booked in that period
     */
    public Booking createBooking(long memberId, long resourceId,
                                 LocalDateTime start, LocalDateTime end)
            throws SQLException, BookingConflictException {
        if (memberId <= 0) throw new ValidationException("member", "Choose a member.");
        if (resourceId <= 0) throw new ValidationException("resource", "Choose a desk or hall.");
        if (start == null) throw new ValidationException("start", "Choose a start time.");
        if (end == null) throw new ValidationException("end", "Choose an end time.");
        try {
            BookingRules.validateInterval(start, end);
        } catch (IllegalArgumentException exception) {
            throw new ValidationException("end", exception.getMessage());
        }
        try {
            return repository.createBooking(memberId, resourceId, start, end);
        } catch (IllegalArgumentException exception) {
            throw new ValidationException("resource", exception.getMessage());
        }
    }

    public void cancelBooking(long bookingId) throws SQLException {
        repository.cancelBooking(bookingId);
    }
}
