package com.workspacehub.service;

import com.workspacehub.model.Resource;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;

/** Pure validation rules for desks and halls. Limits match the database columns. */
public final class ResourceValidator {
    static final int MAX_NAME = 100;
    static final BigDecimal MAX_PRICE = new BigDecimal("9999999999.99");

    private ResourceValidator() {
    }

    public static void validate(Resource resource) {
        Map<String, String> errors = new LinkedHashMap<>();
        String name = resource.name() == null ? "" : resource.name().trim();
        if (name.isEmpty()) errors.put("name", "Enter a name for the desk or hall.");
        else if (name.length() > MAX_NAME) errors.put("name", "The name can be at most " + MAX_NAME + " characters.");
        if (resource.type() == null) errors.put("type", "Choose Desk or Hall.");
        if (resource.capacity() < 1) errors.put("capacity", "Capacity must be at least 1.");
        checkPrice(errors, "dailyPrice", "Daily rate", resource.dailyPrice());
        checkPrice(errors, "monthlyPrice", "Monthly rate", resource.monthlyPrice());
        if (!errors.isEmpty()) throw new ValidationException(errors);
    }

    private static void checkPrice(Map<String, String> errors, String key, String label, BigDecimal value) {
        if (value == null) errors.put(key, label + " is required.");
        else if (value.signum() < 0) errors.put(key, label + " cannot be negative.");
        else if (value.stripTrailingZeros().scale() > 2) errors.put(key, label + " can have at most 2 decimal places.");
        else if (value.compareTo(MAX_PRICE) > 0) errors.put(key, label + " is too large.");
    }
}
