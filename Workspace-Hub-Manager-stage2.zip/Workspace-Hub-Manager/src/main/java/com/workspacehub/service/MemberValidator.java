package com.workspacehub.service;

import com.workspacehub.model.Member;

import java.util.LinkedHashMap;
import java.util.Map;

/** Pure validation rules for member records. Limits match the database columns. */
public final class MemberValidator {
    static final int MAX_NAME = 150;
    static final int MAX_PHONE = 40;
    static final int MAX_EMAIL = 150;

    private MemberValidator() {
    }

    public static void validate(Member member) {
        Map<String, String> errors = new LinkedHashMap<>();
        String name = member.fullName() == null ? "" : member.fullName().trim();
        if (name.isEmpty()) errors.put("fullName", "Enter the member's full name.");
        else if (name.length() > MAX_NAME) errors.put("fullName", "The name can be at most " + MAX_NAME + " characters.");

        String phone = member.phone() == null ? "" : member.phone().trim();
        if (phone.length() > MAX_PHONE) errors.put("phone", "The phone number can be at most " + MAX_PHONE + " characters.");
        else if (!phone.isEmpty() && !isPhoneLike(phone)) {
            errors.put("phone", "Use only digits, spaces, + - and parentheses in the phone number.");
        }

        String email = member.email() == null ? "" : member.email().trim();
        if (email.length() > MAX_EMAIL) errors.put("email", "The email can be at most " + MAX_EMAIL + " characters.");
        else if (!email.isEmpty() && !isEmailLike(email)) errors.put("email", "Enter an email like name@example.com.");

        if (member.id() == 0 && member.joinDate() == null) errors.put("joinDate", "A join date is required.");
        if (!errors.isEmpty()) throw new ValidationException(errors);
    }

    private static boolean isPhoneLike(String phone) {
        boolean hasDigit = false;
        for (char c : phone.toCharArray()) {
            if (Character.isDigit(c)) hasDigit = true;
            else if ("+-() ".indexOf(c) < 0) return false;
        }
        return hasDigit;
    }

    /** Deliberately simple: one @, text on both sides, a dot in the domain, no spaces. */
    private static boolean isEmailLike(String email) {
        int at = email.indexOf('@');
        if (at < 1 || at != email.lastIndexOf('@') || email.chars().anyMatch(Character::isWhitespace)) return false;
        String domain = email.substring(at + 1);
        int dot = domain.lastIndexOf('.');
        return dot > 0 && dot < domain.length() - 1;
    }
}
