package com.workspacehub.config;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.Properties;

/**
 * MySQL connection settings. Lookup order (first complete source wins):
 * <ol>
 *   <li>Environment variables WORKSPACEHUB_DB_URL, WORKSPACEHUB_DB_USER, WORKSPACEHUB_DB_PASSWORD</li>
 *   <li>The properties file named by WORKSPACEHUB_CONFIG</li>
 *   <li>./config/local.properties (git-ignored)</li>
 *   <li>~/.workspace-hub-manager/application.properties</li>
 * </ol>
 * The password is never part of {@link #toString()}.
 */
public record DatabaseConfig(String url, String user, String password) {

    public DatabaseConfig {
        if (url == null || url.isBlank()) throw new ConfigurationException("Database URL is missing.");
        if (user == null || user.isBlank()) throw new ConfigurationException("Database user is missing.");
        password = password == null ? "" : password;
    }

    public static DatabaseConfig load() {
        return load(System.getenv(), Path.of("").toAbsolutePath(), Path.of(System.getProperty("user.home")));
    }

    /** Testable variant: environment, working directory and home directory are injected. */
    static DatabaseConfig load(Map<String, String> env, Path workingDir, Path homeDir) {
        String url = env.get("WORKSPACEHUB_DB_URL");
        if (url != null && !url.isBlank()) {
            return new DatabaseConfig(url, env.get("WORKSPACEHUB_DB_USER"), env.get("WORKSPACEHUB_DB_PASSWORD"));
        }
        String explicit = env.get("WORKSPACEHUB_CONFIG");
        Path[] candidates = {
                explicit == null || explicit.isBlank() ? null : Path.of(explicit),
                workingDir.resolve("config").resolve("local.properties"),
                homeDir.resolve(".workspace-hub-manager").resolve("application.properties")
        };
        for (Path candidate : candidates) {
            if (candidate != null && Files.isRegularFile(candidate)) return fromFile(candidate);
        }
        throw new ConfigurationException("""
                No MySQL settings found. Either set the environment variables WORKSPACEHUB_DB_URL, \
                WORKSPACEHUB_DB_USER and WORKSPACEHUB_DB_PASSWORD, or copy \
                config/local.properties.example to config/local.properties and edit it. \
                See README.md, section 'MySQL setup'.""");
    }

    private static DatabaseConfig fromFile(Path file) {
        Properties properties = new Properties();
        try (InputStream in = Files.newInputStream(file)) {
            properties.load(in);
        } catch (IOException exception) {
            throw new ConfigurationException("Could not read the settings file " + file + ".");
        }
        return new DatabaseConfig(properties.getProperty("db.url"),
                properties.getProperty("db.user"), properties.getProperty("db.password"));
    }

    @Override
    public String toString() {
        return "DatabaseConfig[url=" + url + ", user=" + user + ", password=***]";
    }
}
