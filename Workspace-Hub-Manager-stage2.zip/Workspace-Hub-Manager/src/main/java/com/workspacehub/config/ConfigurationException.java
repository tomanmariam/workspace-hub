package com.workspacehub.config;

/** Raised when the database settings are missing or incomplete. The message never contains secrets. */
public final class ConfigurationException extends RuntimeException {
    public ConfigurationException(String message) {
        super(message);
    }
}
