package com.workspacehub.ui;

import com.workspacehub.data.WorkspaceRepository;
import com.workspacehub.data.WorkspaceRepository.BookingConflictException;
import com.workspacehub.model.Booking;
import com.workspacehub.model.Member;
import com.workspacehub.model.Resource;
import com.workspacehub.model.ResourceType;
import com.workspacehub.model.ServiceStatus;
import com.workspacehub.service.BookingService;
import com.workspacehub.service.MemberService;
import com.workspacehub.service.ResourceService;
import com.workspacehub.service.ValidationException;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Separator;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

public final class MainController {
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");
    private static final DateTimeFormatter DATE_CLOCK = DateTimeFormatter.ofPattern("MMM d · HH:mm");
    private final Stage stage;
    private final WorkspaceRepository repository;
    private final BookingService bookingService;
    private final ResourceService resourceService;
    private final MemberService memberService;
    private final BorderPane shell = new BorderPane();
    private final VBox page = new VBox(18);
    private final Label currentPage = new Label("Dashboard");
    private final VBox sidebar = new VBox(7);
    private TableView<Booking> currentBookingTable;

    public MainController(Stage stage, WorkspaceRepository repository) {
        this.stage = stage;
        this.repository = repository;
        this.bookingService = new BookingService(repository);
        this.resourceService = new ResourceService(repository);
        this.memberService = new MemberService(repository);
    }

    public void show() {
        shell.getStyleClass().add("app-shell");
        shell.setLeft(buildSidebar());
        shell.setTop(buildTopbar());
        page.getStyleClass().add("page-content");
        page.setPadding(new Insets(28, 34, 36, 34));
        javafx.scene.control.ScrollPane scrollPane = new javafx.scene.control.ScrollPane(page);
        scrollPane.setFitToWidth(true);
        scrollPane.setHbarPolicy(javafx.scene.control.ScrollPane.ScrollBarPolicy.NEVER);
        scrollPane.getStyleClass().add("content-scroll");
        shell.setCenter(scrollPane);
        Scene scene = new Scene(shell, 1380, 880);
        var stylesheet = getClass().getResource("/styles.css");
        if (stylesheet != null) scene.getStylesheets().add(stylesheet.toExternalForm());
        stage.setTitle("Workspace Hub Manager");
        stage.setMinWidth(1120);
        stage.setMinHeight(720);
        stage.setScene(scene);
        stage.show();
        showDashboard();
    }

    private Node buildTopbar() {
        HBox top = new HBox(14);
        top.setAlignment(Pos.CENTER_LEFT);
        top.setPadding(new Insets(16, 32, 16, 32));
        top.getStyleClass().add("topbar");
        VBox heading = new VBox(3, currentPage, new Label("Workspace operations"));
        currentPage.getStyleClass().add("topbar-title");
        heading.getChildren().get(1).getStyleClass().add("topbar-subtitle");
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        Label today = new Label(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, MMMM d")));
        today.getStyleClass().add("date-chip");
        top.getChildren().addAll(heading, spacer, today);
        return top;
    }

    private Node buildSidebar() {
        sidebar.setPadding(new Insets(24, 16, 20, 16));
        sidebar.setPrefWidth(242);
        sidebar.getStyleClass().add("sidebar");
        HBox brandMark = new HBox(11);
        brandMark.setAlignment(Pos.CENTER_LEFT);
        StackPane mark = new StackPane(new Label("W"));
        mark.getStyleClass().add("brand-mark");
        Label brand = new Label("Workspace Hub");
        brand.getStyleClass().add("brand-name");
        brandMark.getChildren().addAll(mark, brand);
        Label small = new Label("MANAGEMENT DESK");
        small.getStyleClass().add("sidebar-caption");
        VBox nav = new VBox(7);
        nav.getChildren().addAll(
                navButton("Overview", this::showDashboard, true),
                navButton("Desks & halls", this::showResources, false),
                navButton("Bookings", this::showBookings, false),
                navButton("Members", this::showMembers, false),
                navButton("Services status", this::showServices, false));
        Separator separator = new Separator();
        separator.getStyleClass().add("sidebar-separator");
        Label nextTitle = new Label("NEXT MODULES");
        nextTitle.getStyleClass().add("sidebar-caption");
        Button cafeteria = navButton("Cafeteria & stock", () -> showComingSoon("Cafeteria & stock"), false);
        Button reports = navButton("Reports", () -> showComingSoon("Reports"), false);
        Label buildLabel = new Label("FIRST BUILD  ·  LOCAL DATA");
        buildLabel.getStyleClass().add("sidebar-footer");
        Region grow = new Region();
        VBox.setVgrow(grow, Priority.ALWAYS);
        sidebar.getChildren().addAll(brandMark, spacer(5), small, spacer(2), nav,
                spacer(9), separator, spacer(4), nextTitle, cafeteria, reports, grow, buildLabel);
        return sidebar;
    }

    private Button navButton(String text, Runnable action, boolean selected) {
        Button button = new Button(text);
        button.setMaxWidth(Double.MAX_VALUE);
        button.setAlignment(Pos.CENTER_LEFT);
        button.getStyleClass().add("nav-button");
        if (selected) button.getStyleClass().add("nav-button-selected");
        button.setOnAction(event -> action.run());
        return button;
    }

    private Node spacer(double height) {
        Region region = new Region();
        region.setMinHeight(height);
        region.setPrefHeight(height);
        return region;
    }

    private VBox heading(String title, String subtitle, Button action) {
        VBox block = new VBox(5);
        HBox line = new HBox(14);
        line.setAlignment(Pos.CENTER_LEFT);
        Label titleLabel = new Label(title);
        titleLabel.getStyleClass().add("page-title");
        line.getChildren().add(titleLabel);
        if (action != null) {
            Region spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);
            line.getChildren().addAll(spacer, action);
        }
        Label sub = new Label(subtitle);
        sub.getStyleClass().add("page-subtitle");
        block.getChildren().addAll(line, sub);
        return block;
    }

    private Button primaryButton(String text, Runnable action) {
        Button button = new Button(text);
        button.getStyleClass().add("primary-button");
        button.setOnAction(event -> action.run());
        return button;
    }

    private void showDashboard() {
        currentPage.setText("Dashboard");
        try {
            HBox stats = new HBox(14,
                    metric("Available now", repository.countAvailableNow(), "active desks and halls"),
                    metric("Bookings today", repository.countBookingsOn(LocalDate.now()), "scheduled for today"),
                    metric("Active resources", repository.countActiveResources(), "desks and halls"),
                    metric("Members", repository.countMembers(), "registered in this workspace"));
            HBox.setHgrow(stats.getChildren().get(0), Priority.ALWAYS);
            HBox.setHgrow(stats.getChildren().get(1), Priority.ALWAYS);
            HBox.setHgrow(stats.getChildren().get(2), Priority.ALWAYS);
            HBox.setHgrow(stats.getChildren().get(3), Priority.ALWAYS);
            HBox services = serviceSummaryCards();
            TableView<Booking> table = bookingTable(repository.listBookings(LocalDate.now(), ""));
            VBox bookingsCard = sectionCard("Today's bookings", "A quick view of the schedule", table);
            VBox.setVgrow(bookingsCard, Priority.ALWAYS);
            page.getChildren().setAll(heading("Good day. Here's your workspace.",
                    "A clear view of availability, bookings, and essential services.",
                    primaryButton("+ New booking", this::openBookingDialog)), stats,
                    sectionLabel("SERVICE PULSE", "Staff-updated status with a timestamped history."), services,
                    bookingsCard);
        } catch (Exception exception) {
            showError("Could not load the dashboard", exception);
        }
    }

    private Node metric(String title, long value, String detail) {
        VBox card = new VBox(8);
        card.getStyleClass().add("metric-card");
        Label eyebrow = new Label(title.toUpperCase());
        eyebrow.getStyleClass().add("metric-eyebrow");
        Label number = new Label(Long.toString(value));
        number.getStyleClass().add("metric-number");
        Label caption = new Label(detail);
        caption.getStyleClass().add("metric-caption");
        card.getChildren().addAll(eyebrow, number, caption);
        return card;
    }

    private HBox serviceSummaryCards() throws SQLException {
        HBox row = new HBox(14);
        List<ServiceStatus> statuses = repository.latestServiceStatuses();
        for (ServiceStatus status : statuses) {
            VBox card = new VBox(6);
            card.getStyleClass().add("service-card");
            Label name = new Label(status.displayName());
            name.getStyleClass().add("service-title");
            Label state = new Label(status.state().replace('_', ' '));
            state.getStyleClass().add(status.state().equals("OUTAGE") || status.state().equals("DOWN")
                    ? "status-warning" : "status-ok");
            String updated = status.updatedAt().format(DATE_CLOCK);
            Label details = new Label(status.detail().isBlank() ? "Updated " + updated
                    : status.detail() + " · " + updated);
            details.getStyleClass().add("service-detail");
            card.getChildren().addAll(name, state, details);
            HBox.setHgrow(card, Priority.ALWAYS);
            row.getChildren().add(card);
        }
        return row;
    }

    private Node sectionLabel(String title, String subtitle) {
        VBox label = new VBox(3);
        Label top = new Label(title);
        top.getStyleClass().add("section-eyebrow");
        Label sub = new Label(subtitle);
        sub.getStyleClass().add("section-caption");
        label.getChildren().addAll(top, sub);
        return label;
    }

    private VBox sectionCard(String title, String subtitle, Node content) {
        VBox card = new VBox(14);
        card.getStyleClass().add("surface-card");
        Label heading = new Label(title);
        heading.getStyleClass().add("card-title");
        Label caption = new Label(subtitle);
        caption.getStyleClass().add("section-caption");
        VBox headingBox = new VBox(3, heading, caption);
        card.getChildren().addAll(headingBox, content);
        return card;
    }

    private void showResources() {
        currentPage.setText("Desks & halls");
        try {
            List<Resource> resources = repository.listResources(true);
            var bookedNow = repository.bookedResourceIdsNow();
            TableView<Resource> table = new TableView<>(FXCollections.observableArrayList(resources));
            table.getStyleClass().add("data-table");
            column(table, "Resource", r -> r.name(), 1.3);
            column(table, "Type", r -> r.type().label(), .75);
            column(table, "Capacity", r -> Integer.toString(r.capacity()), .65);
            column(table, "Daily rate", r -> r.dailyPrice().stripTrailingZeros().toPlainString(), .8);
            column(table, "Monthly rate", r -> r.monthlyPrice().stripTrailingZeros().toPlainString(), .9);
            column(table, "Availability", r -> !r.active() ? "Inactive"
                    : bookedNow.contains(r.id()) ? "Booked now" : "Available now", .9);
            TableColumn<Resource, Void> actions = actionColumn("Edit", resource -> {
                Optional<Resource> edited = resourceDialog(resource);
                edited.ifPresent(value -> saveResource(value, true));
            });
            table.getColumns().add(actions);
            Button add = primaryButton("+ Add resource", () -> resourceDialog(null).ifPresent(value -> saveResource(value, false)));
            Button toggle = secondaryButton("Activate / deactivate selected", () -> {
                Resource selected = table.getSelectionModel().getSelectedItem();
                if (selected == null) { showInfo("Select a desk or hall first."); return; }
                try {
                    repository.saveResource(new Resource(selected.id(), selected.name(), selected.type(), selected.capacity(),
                            selected.dailyPrice(), selected.monthlyPrice(), !selected.active()));
                    showResources();
                } catch (SQLException exception) { showError("Could not update resource", exception); }
            });
            HBox tools = new HBox(10, toggle);
            page.getChildren().setAll(heading("Desks & halls", "Manage bookable workspace resources and their rates.", add),
                    tools, sectionCard("Workspace inventory", "Inactive resources stay in the record but are no longer bookable.", table));
        } catch (Exception exception) { showError("Could not load resources", exception); }
    }

    private Optional<Resource> resourceDialog(Resource existing) {
        Dialog<Resource> dialog = new Dialog<>();
        dialog.setTitle(existing == null ? "Add resource" : "Edit resource");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        TextField name = new TextField(existing == null ? "" : existing.name());
        name.setPromptText("e.g. Desk A-04");
        ComboBox<ResourceType> type = new ComboBox<>(FXCollections.observableArrayList(ResourceType.values()));
        type.setValue(existing == null ? ResourceType.DESK : existing.type());
        TextField capacity = new TextField(existing == null ? "1" : Integer.toString(existing.capacity()));
        TextField daily = new TextField(existing == null ? "0" : existing.dailyPrice().toPlainString());
        TextField monthly = new TextField(existing == null ? "0" : existing.monthlyPrice().toPlainString());
        GridPane form = formGrid();
        addFormRow(form, 0, "Name", name);
        addFormRow(form, 1, "Type", type);
        addFormRow(form, 2, "Capacity", capacity);
        addFormRow(form, 3, "Daily rate", daily);
        addFormRow(form, 4, "Monthly rate", monthly);
        dialog.getDialogPane().setContent(form);
        dialog.setResultConverter(button -> {
            if (button != ButtonType.OK) return null;
            try {
                String resourceName = name.getText().trim();
                int seats = Integer.parseInt(capacity.getText().trim());
                BigDecimal dailyRate = new BigDecimal(daily.getText().trim());
                BigDecimal monthlyRate = new BigDecimal(monthly.getText().trim());
                if (resourceName.isBlank() || seats < 1 || dailyRate.signum() < 0 || monthlyRate.signum() < 0) {
                    throw new IllegalArgumentException("Enter a name, a positive capacity, and non-negative rates.");
                }
                return new Resource(existing == null ? 0 : existing.id(), resourceName, type.getValue(), seats,
                        dailyRate, monthlyRate, existing == null || existing.active());
            } catch (Exception exception) {
                showError("Check the resource details", exception);
                return null;
            }
        });
        return dialog.showAndWait();
    }

    private void saveResource(Resource resource, boolean editing) {
        try { resourceService.save(resource); showResources(); }
        catch (ValidationException exception) { showInfo(exception.getMessage()); }
        catch (SQLException exception) { showError(editing ? "Could not save changes" : "Could not add resource", exception); }
    }

    private void showMembers() {
        currentPage.setText("Members");
        try {
            TextField search = new TextField();
            search.setPromptText("Search name, phone, or email");
            Button find = secondaryButton("Search", () -> reloadMembers(search.getText()));
            HBox filters = new HBox(10, search, find);
            HBox.setHgrow(search, Priority.ALWAYS);
            TableView<Member> table = memberTable(repository.searchMembers(""));
            table.getSelectionModel().setSelectionMode(javafx.scene.control.SelectionMode.SINGLE);
            Button edit = secondaryButton("Edit selected", () -> {
                Member selected = table.getSelectionModel().getSelectedItem();
                if (selected == null) { showInfo("Select a member first."); return; }
                memberDialog(selected).ifPresent(this::saveMember);
            });
            Button add = primaryButton("+ Add member", () -> memberDialog(null).ifPresent(this::saveMember));
            HBox actions = new HBox(10, edit);
            page.getChildren().setAll(heading("Members", "Keep subscriber contact records together and searchable.", add),
                    filters, actions, sectionCard("Member directory", "Sample entries are clearly labelled and can be edited.", table));
        } catch (Exception exception) { showError("Could not load members", exception); }
    }

    private TableView<Member> memberTable(List<Member> members) {
        TableView<Member> table = new TableView<>(FXCollections.observableArrayList(members));
        table.getStyleClass().add("data-table");
        column(table, "Name", Member::fullName, 1.2);
        column(table, "Phone", m -> blankAsDash(m.phone()), .95);
        column(table, "Email", m -> blankAsDash(m.email()), 1.35);
        column(table, "Joined", m -> m.joinDate().toString(), .75);
        return table;
    }

    private void reloadMembers(String filter) {
        try {
            TableView<Member> table = memberTable(repository.searchMembers(filter));
            Node existingHeading = page.getChildren().get(0);
            Node tools = page.getChildren().get(1);
            Node actions = page.getChildren().get(2);
            Node card = sectionCard("Member directory", "Filtered results", table);
            page.getChildren().setAll(existingHeading, tools, actions, card);
        } catch (Exception exception) { showError("Could not search members", exception); }
    }

    private Optional<Member> memberDialog(Member existing) {
        Dialog<Member> dialog = new Dialog<>();
        dialog.setTitle(existing == null ? "Add member" : "Edit member");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        TextField fullName = new TextField(existing == null ? "" : existing.fullName());
        TextField phone = new TextField(existing == null ? "" : existing.phone());
        TextField email = new TextField(existing == null ? "" : existing.email());
        GridPane form = formGrid();
        addFormRow(form, 0, "Full name", fullName);
        addFormRow(form, 1, "Phone", phone);
        addFormRow(form, 2, "Email", email);
        dialog.getDialogPane().setContent(form);
        dialog.setResultConverter(button -> {
            if (button != ButtonType.OK) return null;
            if (fullName.getText().isBlank()) {
                showInfo("A member name is required.");
                return null;
            }
            return new Member(existing == null ? 0 : existing.id(), fullName.getText().trim(),
                    phone.getText().trim(), email.getText().trim(),
                    existing == null ? LocalDate.now() : existing.joinDate());
        });
        return dialog.showAndWait();
    }

    private void saveMember(Member member) {
        try { memberService.save(member); showMembers(); }
        catch (ValidationException exception) { showInfo(exception.getMessage()); }
        catch (SQLException exception) { showError("Could not save member", exception); }
    }

    private void showBookings() {
        currentPage.setText("Bookings");
        try {
            DatePicker day = new DatePicker(LocalDate.now());
            Button today = secondaryButton("Today", () -> { day.setValue(LocalDate.now()); refreshBookings(day.getValue(), ""); });
            TextField search = new TextField();
            search.setPromptText("Search member, resource, or status");
            Button find = secondaryButton("Filter", () -> refreshBookings(day.getValue(), search.getText()));
            HBox filters = new HBox(10, day, today, search, find);
            HBox.setHgrow(search, Priority.ALWAYS);
            day.setOnAction(event -> refreshBookings(day.getValue(), search.getText()));
            currentBookingTable = bookingTable(repository.listBookings(LocalDate.now(), ""));
            Button cancel = secondaryButton("Cancel selected booking", () -> {
                Booking selected = currentBookingTable.getSelectionModel().getSelectedItem();
                if (selected == null) { showInfo("Select a booking first."); return; }
                if (!selected.status().equals("ACTIVE")) { showInfo("This booking is already cancelled."); return; }
                Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION,
                        "Cancel the booking for " + selected.memberName() + "?", ButtonType.YES, ButtonType.NO);
                confirmation.setHeaderText("Cancel booking");
                if (confirmation.showAndWait().orElse(ButtonType.NO) == ButtonType.YES) {
                    try { bookingService.cancelBooking(selected.id()); refreshBookings(day.getValue(), search.getText()); }
                    catch (SQLException exception) { showError("Could not cancel booking", exception); }
                }
            });
            page.getChildren().setAll(heading("Bookings", "Create clear time slots and prevent double-booking.",
                    primaryButton("+ New booking", this::openBookingDialog)), filters, cancel,
                    sectionCard("Booking schedule", "Times are shown in the workspace computer's local time.", currentBookingTable));
        } catch (Exception exception) { showError("Could not load bookings", exception); }
    }

    private void refreshBookings(LocalDate day, String filter) {
        try {
            currentBookingTable = bookingTable(repository.listBookings(day, filter));
            Node pageHeading = page.getChildren().get(0);
            Node filters = page.getChildren().get(1);
            Node actions = page.getChildren().get(2);
            Node card = sectionCard("Booking schedule", "Times are shown in local time.", currentBookingTable);
            page.getChildren().setAll(pageHeading, filters, actions, card);
        } catch (Exception exception) { showError("Could not filter bookings", exception); }
    }

    private TableView<Booking> bookingTable(List<Booking> bookings) {
        TableView<Booking> table = new TableView<>(FXCollections.observableArrayList(bookings));
        table.getStyleClass().add("data-table");
        column(table, "Member", Booking::memberName, 1.0);
        column(table, "Desk / hall", Booking::resourceName, 1.0);
        column(table, "Starts", b -> b.startTime().format(DATE_CLOCK), 1.0);
        column(table, "Ends", b -> b.endTime().format(DATE_CLOCK), 1.0);
        column(table, "Status", Booking::status, .7);
        return table;
    }

    private void openBookingDialog() {
        try {
            List<Member> members = repository.searchMembers("");
            List<Resource> resources = repository.listResources(false);
            if (members.isEmpty() || resources.isEmpty()) {
                showInfo("Add at least one member and one active desk or hall before creating a booking.");
                return;
            }
            Dialog<BookingInput> dialog = new Dialog<>();
            dialog.setTitle("Create booking");
            dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
            ComboBox<Member> member = new ComboBox<>(FXCollections.observableArrayList(members));
            ComboBox<Resource> resource = new ComboBox<>(FXCollections.observableArrayList(resources));
            member.setValue(members.getFirst());
            resource.setValue(resources.getFirst());
            DatePicker startDate = new DatePicker(LocalDate.now());
            TextField startTime = new TextField("09:00");
            DatePicker endDate = new DatePicker(LocalDate.now());
            TextField endTime = new TextField("10:00");
            GridPane form = formGrid();
            addFormRow(form, 0, "Member", member);
            addFormRow(form, 1, "Desk or hall", resource);
            addFormRow(form, 2, "Start date", startDate);
            addFormRow(form, 3, "Start time", startTime);
            addFormRow(form, 4, "End date", endDate);
            addFormRow(form, 5, "End time", endTime);
            dialog.getDialogPane().setContent(form);
            dialog.setResultConverter(button -> {
                if (button != ButtonType.OK) return null;
                try {
                    LocalDateTime from = LocalDateTime.of(startDate.getValue(), LocalTime.parse(startTime.getText().trim(), CLOCK));
                    LocalDateTime to = LocalDateTime.of(endDate.getValue(), LocalTime.parse(endTime.getText().trim(), CLOCK));
                    return new BookingInput(member.getValue(), resource.getValue(), from, to);
                } catch (Exception exception) {
                    showError("Enter dates and times in the format HH:mm", exception);
                    return null;
                }
            });
            Optional<BookingInput> result = dialog.showAndWait();
            result.ifPresent(input -> {
                try {
                    bookingService.createBooking(input.member().id(), input.resource().id(), input.start(), input.end());
                    showInfo("Booking saved. The time slot is reserved.");
                    if (currentPage.getText().equals("Bookings")) showBookings(); else showDashboard();
                } catch (BookingConflictException | ValidationException exception) {
                    showInfo(exception.getMessage());
                } catch (Exception exception) { showError("Could not create booking", exception); }
            });
        } catch (Exception exception) { showError("Could not prepare a booking", exception); }
    }

    private record BookingInput(Member member, Resource resource, LocalDateTime start, LocalDateTime end) { }

    private void showServices() {
        currentPage.setText("Services status");
        try {
            VBox list = new VBox(14);
            for (ServiceStatus status : repository.latestServiceStatuses()) {
                HBox row = new HBox(18);
                row.setAlignment(Pos.CENTER_LEFT);
                row.getStyleClass().add("service-row");
                VBox info = new VBox(5);
                Label name = new Label(status.displayName());
                name.getStyleClass().add("card-title");
                Label description = new Label(status.state().replace('_', ' ') + " · " + blankAsDash(status.detail()));
                description.getStyleClass().add("section-caption");
                Label timestamp = new Label("Last updated " + status.updatedAt().format(DATE_CLOCK));
                timestamp.getStyleClass().add("service-detail");
                info.getChildren().addAll(name, description, timestamp);
                Region spacer = new Region();
                HBox.setHgrow(spacer, Priority.ALWAYS);
                Button update = secondaryButton("Update status", () -> openStatusDialog(status));
                row.getChildren().addAll(info, spacer, update);
                list.getChildren().add(row);
            }
            TableView<ServiceStatus> history = new TableView<>(
                    FXCollections.observableArrayList(repository.serviceHistory()));
            history.getStyleClass().add("data-table");
            column(history, "Service", ServiceStatus::displayName, .8);
            column(history, "Status", value -> value.state().replace('_', ' '), .8);
            column(history, "Details", value -> blankAsDash(value.detail()), 1.4);
            column(history, "Updated", value -> value.updatedAt().format(DATE_CLOCK), 1.0);
            page.getChildren().setAll(heading("Services status", "Record manual updates for power and internet reliability.", null),
                    sectionCard("Current service conditions", "Every change is stored as a timestamped history entry.", list),
                    sectionCard("Recent history", "Latest 100 service updates.", history));
        } catch (Exception exception) { showError("Could not load service statuses", exception); }
    }

    private void openStatusDialog(ServiceStatus existing) {
        boolean isPower = existing.service().equals("POWER");
        Dialog<StatusInput> dialog = new Dialog<>();
        dialog.setTitle("Update " + existing.displayName().toLowerCase());
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        List<String> choices = isPower
                ? List.of("GRID", "GENERATOR", "SOLAR_BATTERY", "OUTAGE")
                : List.of("STABLE", "SLOW", "DOWN");
        ComboBox<String> state = new ComboBox<>(FXCollections.observableArrayList(choices));
        state.setValue(existing.state());
        TextField details = new TextField(existing.detail());
        details.setPromptText(isPower ? "Optional notes about the source" : "Optional speed or connection notes");
        GridPane form = formGrid();
        addFormRow(form, 0, "Status", state);
        addFormRow(form, 1, "Details", details);
        dialog.getDialogPane().setContent(form);
        dialog.setResultConverter(button -> button == ButtonType.OK
                ? new StatusInput(existing.service(), state.getValue(), details.getText()) : null);
        dialog.showAndWait().ifPresent(input -> {
            try { repository.updateServiceStatus(input.service(), input.state(), input.detail()); showServices(); }
            catch (SQLException exception) { showError("Could not update service status", exception); }
        });
    }

    private record StatusInput(String service, String state, String detail) { }

    private void showComingSoon(String name) {
        currentPage.setText(name);
        page.getChildren().setAll(heading(name, "This module is in the next implementation stage.", null),
                sectionCard("Planned for the next pass", "The report includes this module. This first build focuses on the database-backed booking workflow, resources, members, and staff-entered service status.",
                        new Label("Your existing data remains local and unchanged.")));
    }

    private <T> void column(TableView<T> table, String title,
                            java.util.function.Function<T, String> text, double grow) {
        TableColumn<T, String> column = new TableColumn<>(title);
        column.setCellValueFactory(value -> new ReadOnlyStringWrapper(text.apply(value.getValue())));
        column.setPrefWidth(120 * grow);
        column.setMinWidth(80);
        column.setStyle("-fx-alignment: CENTER-LEFT;");
        table.getColumns().add(column);
        column.setResizable(true);
    }

    private <T> TableColumn<T, Void> actionColumn(String text, java.util.function.Consumer<T> action) {
        TableColumn<T, Void> column = new TableColumn<>("Action");
        column.setPrefWidth(110);
        column.setCellFactory(ignored -> new TableCell<>() {
            private final Button button = secondaryButton(text, () -> {
                T item = getTableView().getItems().get(getIndex());
                action.accept(item);
            });
            @Override protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : button);
            }
        });
        return column;
    }

    private GridPane formGrid() {
        GridPane grid = new GridPane();
        grid.setHgap(14);
        grid.setVgap(12);
        grid.setPadding(new Insets(12));
        ColumnConstraints labels = new ColumnConstraints();
        labels.setMinWidth(112);
        ColumnConstraints fields = new ColumnConstraints();
        fields.setHgrow(Priority.ALWAYS);
        grid.getColumnConstraints().addAll(labels, fields);
        return grid;
    }

    private void addFormRow(GridPane grid, int row, String label, Node field) {
        Label caption = new Label(label);
        caption.getStyleClass().add("form-label");
        if (field instanceof Region region) region.setMaxWidth(Double.MAX_VALUE);
        GridPane.setHgrow(field, Priority.ALWAYS);
        grid.add(caption, 0, row);
        grid.add(field, 1, row);
    }

    private Button secondaryButton(String text, Runnable action) {
        Button button = new Button(text);
        button.getStyleClass().add("secondary-button");
        button.setOnAction(event -> action.run());
        return button;
    }

    private static String blankAsDash(String value) {
        return value == null || value.isBlank() ? "—" : value;
    }

    private void showError(String title, Exception exception) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Workspace Hub Manager");
        alert.setHeaderText(title);
        alert.setContentText(exception.getMessage() == null ? exception.getClass().getSimpleName() : exception.getMessage());
        alert.showAndWait();
    }

    private void showInfo(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Workspace Hub Manager");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
