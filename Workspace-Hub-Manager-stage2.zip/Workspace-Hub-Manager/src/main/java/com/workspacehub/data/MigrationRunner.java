package com.workspacehub.data;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Applies versioned SQL scripts from classpath:/db/migration (V1__name.sql, V2__name.sql, ...).
 * Applied versions are recorded in schema_version. A GET_LOCK guard prevents two app instances
 * from migrating at once. Note: MySQL DDL auto-commits, so a failed script can leave a partial
 * change; keep each script small and fix forward with a new version.
 */
final class MigrationRunner {
    /** Add new scripts here, in order. Listing them avoids classpath scanning problems in packaged jars. */
    static final List<String> SCRIPTS = List.of("V1__initial_schema.sql");

    void migrate(Connection connection) throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS schema_version (
                        version INT NOT NULL PRIMARY KEY,
                        description VARCHAR(200) NOT NULL,
                        applied_at DATETIME NOT NULL
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                    """);
        }
        if (!acquireLock(connection)) throw new SQLException("Another instance is upgrading the database. Try again shortly.");
        try {
            Set<Integer> applied = appliedVersions(connection);
            for (String script : SCRIPTS) {
                int version = Integer.parseInt(script.substring(1, script.indexOf("__")));
                if (applied.contains(version)) continue;
                for (String sql : readStatements(script)) {
                    try (Statement statement = connection.createStatement()) {
                        statement.executeUpdate(sql);
                    }
                }
                try (PreparedStatement record = connection.prepareStatement(
                        "INSERT INTO schema_version(version, description, applied_at) VALUES(?, ?, NOW())")) {
                    record.setInt(1, version);
                    record.setString(2, script.substring(script.indexOf("__") + 2, script.length() - 4));
                    record.executeUpdate();
                }
            }
        } finally {
            releaseLock(connection);
        }
    }

    private static boolean acquireLock(Connection connection) throws SQLException {
        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery("SELECT GET_LOCK('workspacehub_migration', 15)")) {
            return result.next() && result.getInt(1) == 1;
        }
    }

    private static void releaseLock(Connection connection) throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.executeQuery("SELECT RELEASE_LOCK('workspacehub_migration')").close();
        }
    }

    private static Set<Integer> appliedVersions(Connection connection) throws SQLException {
        Set<Integer> versions = new HashSet<>();
        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery("SELECT version FROM schema_version")) {
            while (result.next()) versions.add(result.getInt(1));
        }
        return versions;
    }

    private static List<String> readStatements(String script) throws SQLException {
        try (InputStream in = MigrationRunner.class.getResourceAsStream("/db/migration/" + script)) {
            if (in == null) throw new SQLException("Missing migration script " + script);
            String text = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            List<String> statements = new ArrayList<>();
            for (String part : text.split(";\\s*(\\r?\\n|$)")) {
                if (!part.isBlank()) statements.add(part.strip());
            }
            return statements;
        } catch (IOException exception) {
            throw new SQLException("Could not read migration script " + script, exception);
        }
    }
}
