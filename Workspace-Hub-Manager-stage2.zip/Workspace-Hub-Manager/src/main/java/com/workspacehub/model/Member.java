package com.workspacehub.model;

import java.time.LocalDate;

public record Member(long id, String fullName, String phone, String email, LocalDate joinDate) {
    @Override
    public String toString() {
        return fullName;
    }
}
