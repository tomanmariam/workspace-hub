package com.workspacehub.model;

public enum ResourceType {
    DESK("Desk"),
    HALL("Hall");

    private final String label;

    ResourceType(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }

    @Override
    public String toString() {
        return label;
    }
}
