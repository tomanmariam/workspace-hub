package com.workspacehub.model;

import java.time.LocalDateTime;

public record Booking(
        long id,
        long memberId,
        String memberName,
        long resourceId,
        String resourceName,
        LocalDateTime startTime,
        LocalDateTime endTime,
        String status
) {
}
