package com.workspacehub.model;

import java.time.LocalDateTime;

public record ServiceStatus(String service, String state, String detail, LocalDateTime updatedAt) {
    public String displayName() {
        return switch (service) {
            case "POWER" -> "Power supply";
            case "INTERNET" -> "Internet";
            default -> service;
        };
    }
}
