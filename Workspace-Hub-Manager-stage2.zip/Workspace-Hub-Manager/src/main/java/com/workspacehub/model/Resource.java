package com.workspacehub.model;

import java.math.BigDecimal;

public record Resource(
        long id,
        String name,
        ResourceType type,
        int capacity,
        BigDecimal dailyPrice,
        BigDecimal monthlyPrice,
        boolean active
) {
    @Override
    public String toString() {
        return name + " · " + type.label();
    }
}
