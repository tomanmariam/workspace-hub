package com.workspacehub.tools;

import com.workspacehub.config.DatabaseConfig;
import com.workspacehub.data.WorkspaceRepository;

import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Properties;

/**
 * One-off import of the old local SQLite database into MySQL, keeping every row and its id.
 *
 * <pre>
 *   mvnw.cmd compile exec:java "-Dexec.mainClass=com.workspacehub.tools.SqliteImporter" "-Dexec.args=C:\path\workspace-hub.db"
 *   ... add --replace to first delete ALL rows currently in the MySQL database (e.g. the sample data)
 * </pre>
 *
 * The SQLite file is opened read-only and is never modified. All MySQL changes happen in one
 * transaction: if anything fails, nothing is imported.
 */
public final class SqliteImporter {
    public record Result(int resources, int members, int bookings, int serviceEntries) {
    }

    private SqliteImporter() {
    }

    public static void main(String[] args) {
        if (args.length < 1 || args.length > 2 || (args.length == 2 && !args[1].equals("--replace"))) {
            System.err.println("Usage: SqliteImporter <path-to-old-workspace-hub.db> [--replace]");
            System.exit(2);
        }
        Path file = Path.of(args[0]);
        boolean replace = args.length == 2;
        try {
            DatabaseConfig config = DatabaseConfig.load();
            new WorkspaceRepository(config).initialize();
            Result result;
            try (Connection mysql = DriverManager.getConnection(config.url(), config.user(), config.password());
                 Connection sqlite = openSqliteReadOnly(file)) {
                result = importInto(mysql, sqlite, replace);
            }
            System.out.printf("Imported %d resources, %d members, %d bookings, %d service history entries.%n",
                    result.resources(), result.members(), result.bookings(), result.serviceEntries());
        } catch (Exception exception) {
            System.err.println("Import failed, nothing was changed: " + exception.getMessage());
            System.exit(1);
        }
    }

    static Connection openSqliteReadOnly(Path file) throws SQLException {
        if (!Files.isRegularFile(file)) throw new SQLException("SQLite file not found: " + file);
        Properties properties = new Properties();
        properties.setProperty("open_mode", "1"); // SQLITE_OPEN_READONLY
        return DriverManager.getConnection("jdbc:sqlite:" + file.toAbsolutePath(), properties);
    }

    public static Result importInto(Connection mysql, Connection sqlite, boolean replace) throws SQLException {
        mysql.setAutoCommit(false);
        try {
            long existing = countAll(mysql);
            if (existing > 0 && !replace) {
                throw new SQLException("The MySQL database already contains " + existing
                        + " rows. Re-run with --replace to delete them first (this removes the current MySQL data).");
            }
            if (replace) {
                for (String table : new String[]{"booking", "service_history", "member", "resource"}) {
                    try (Statement statement = mysql.createStatement()) {
                        statement.executeUpdate("DELETE FROM " + table);
                    }
                }
            }
            int resources = copyResources(mysql, sqlite);
            int members = copyMembers(mysql, sqlite);
            int bookings = copyBookings(mysql, sqlite);
            int service = copyServiceHistory(mysql, sqlite);
            mysql.commit();
            return new Result(resources, members, bookings, service);
        } catch (SQLException | RuntimeException exception) {
            mysql.rollback();
            throw exception;
        } finally {
            mysql.setAutoCommit(true);
        }
    }

    private static long countAll(Connection mysql) throws SQLException {
        long total = 0;
        for (String table : new String[]{"resource", "member", "booking", "service_history"}) {
            try (Statement statement = mysql.createStatement();
                 ResultSet result = statement.executeQuery("SELECT COUNT(*) FROM " + table)) {
                result.next();
                total += result.getLong(1);
            }
        }
        return total;
    }

    private static int copyResources(Connection mysql, Connection sqlite) throws SQLException {
        int count = 0;
        try (Statement read = sqlite.createStatement();
             ResultSet rows = read.executeQuery("SELECT id, name, type, capacity, daily_price, monthly_price, active FROM resource ORDER BY id");
             PreparedStatement insert = mysql.prepareStatement(
                     "INSERT INTO resource(id, name, type, capacity, daily_price, monthly_price, active) VALUES(?,?,?,?,?,?,?)")) {
            while (rows.next()) {
                insert.setLong(1, rows.getLong("id"));
                insert.setString(2, rows.getString("name"));
                insert.setString(3, rows.getString("type"));
                insert.setInt(4, rows.getInt("capacity"));
                insert.setBigDecimal(5, price(rows.getString("daily_price"), "daily price", rows.getLong("id")));
                insert.setBigDecimal(6, price(rows.getString("monthly_price"), "monthly price", rows.getLong("id")));
                insert.setInt(7, rows.getInt("active"));
                insert.executeUpdate();
                count++;
            }
        }
        return count;
    }

    private static int copyMembers(Connection mysql, Connection sqlite) throws SQLException {
        int count = 0;
        try (Statement read = sqlite.createStatement();
             ResultSet rows = read.executeQuery("SELECT id, full_name, phone, email, join_date FROM member ORDER BY id");
             PreparedStatement insert = mysql.prepareStatement(
                     "INSERT INTO member(id, full_name, phone, email, join_date) VALUES(?,?,?,?,?)")) {
            while (rows.next()) {
                insert.setLong(1, rows.getLong("id"));
                insert.setString(2, rows.getString("full_name"));
                insert.setString(3, rows.getString("phone"));
                insert.setString(4, rows.getString("email"));
                insert.setObject(5, LocalDate.parse(rows.getString("join_date")));
                insert.executeUpdate();
                count++;
            }
        }
        return count;
    }

    private static int copyBookings(Connection mysql, Connection sqlite) throws SQLException {
        int count = 0;
        try (Statement read = sqlite.createStatement();
             ResultSet rows = read.executeQuery("SELECT id, member_id, resource_id, start_time, end_time, status, created_at FROM booking ORDER BY id");
             PreparedStatement insert = mysql.prepareStatement(
                     "INSERT INTO booking(id, member_id, resource_id, start_time, end_time, status, created_at) VALUES(?,?,?,?,?,?,?)")) {
            while (rows.next()) {
                insert.setLong(1, rows.getLong("id"));
                insert.setLong(2, rows.getLong("member_id"));
                insert.setLong(3, rows.getLong("resource_id"));
                insert.setObject(4, LocalDateTime.parse(rows.getString("start_time")));
                insert.setObject(5, LocalDateTime.parse(rows.getString("end_time")));
                insert.setString(6, rows.getString("status"));
                insert.setObject(7, LocalDateTime.parse(rows.getString("created_at")));
                insert.executeUpdate();
                count++;
            }
        }
        return count;
    }

    private static int copyServiceHistory(Connection mysql, Connection sqlite) throws SQLException {
        int count = 0;
        try (Statement read = sqlite.createStatement();
             ResultSet rows = read.executeQuery("SELECT id, service, state, detail, updated_at FROM service_history ORDER BY id");
             PreparedStatement insert = mysql.prepareStatement(
                     "INSERT INTO service_history(id, service, state, detail, updated_at) VALUES(?,?,?,?,?)")) {
            while (rows.next()) {
                insert.setLong(1, rows.getLong("id"));
                insert.setString(2, rows.getString("service"));
                insert.setString(3, rows.getString("state"));
                insert.setString(4, rows.getString("detail"));
                insert.setObject(5, LocalDateTime.parse(rows.getString("updated_at")));
                insert.executeUpdate();
                count++;
            }
        }
        return count;
    }

    /** Refuses prices MySQL would silently round, so no amount changes during the move. */
    private static BigDecimal price(String text, String label, long resourceId) throws SQLException {
        BigDecimal value = new BigDecimal(text.trim());
        if (value.stripTrailingZeros().scale() > 2) {
            throw new SQLException("Resource " + resourceId + " has a " + label + " (" + text
                    + ") with more than 2 decimal places. Fix it in the old app first.");
        }
        return value;
    }
}
