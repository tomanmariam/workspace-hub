CREATE TABLE resource (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type VARCHAR(10) NOT NULL,
    capacity INT NOT NULL DEFAULT 1,
    daily_price DECIMAL(12,2) NOT NULL DEFAULT 0,
    monthly_price DECIMAL(12,2) NOT NULL DEFAULT 0,
    active TINYINT(1) NOT NULL DEFAULT 1,
    CONSTRAINT uq_resource_name UNIQUE (name),
    CONSTRAINT ck_resource_type CHECK (type IN ('DESK', 'HALL')),
    CONSTRAINT ck_resource_capacity CHECK (capacity > 0),
    CONSTRAINT ck_resource_prices CHECK (daily_price >= 0 AND monthly_price >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE member (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    phone VARCHAR(40) NOT NULL DEFAULT '',
    email VARCHAR(150) NOT NULL DEFAULT '',
    join_date DATE NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE INDEX idx_member_name ON member (full_name);
CREATE TABLE booking (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    member_id BIGINT NOT NULL,
    resource_id BIGINT NOT NULL,
    start_time DATETIME NOT NULL,
    end_time DATETIME NOT NULL,
    status VARCHAR(10) NOT NULL DEFAULT 'ACTIVE',
    created_at DATETIME NOT NULL,
    CONSTRAINT fk_booking_member FOREIGN KEY (member_id) REFERENCES member (id),
    CONSTRAINT fk_booking_resource FOREIGN KEY (resource_id) REFERENCES resource (id),
    CONSTRAINT ck_booking_status CHECK (status IN ('ACTIVE', 'CANCELLED')),
    CONSTRAINT ck_booking_interval CHECK (end_time > start_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE INDEX idx_booking_resource_period ON booking (resource_id, status, start_time, end_time);
CREATE INDEX idx_booking_start ON booking (start_time);
CREATE TABLE service_history (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    service VARCHAR(10) NOT NULL,
    state VARCHAR(30) NOT NULL,
    detail VARCHAR(255) NOT NULL DEFAULT '',
    updated_at DATETIME NOT NULL,
    CONSTRAINT ck_service_name CHECK (service IN ('POWER', 'INTERNET'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE INDEX idx_service_latest ON service_history (service, updated_at, id);
