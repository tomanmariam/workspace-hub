package com.workspacehub.data;

import com.workspacehub.model.Booking;
import com.workspacehub.model.Member;
import com.workspacehub.model.Resource;
import com.workspacehub.model.ResourceType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class WorkspaceRepositoryTest {
    // Fixed dates keep the tests independent of today's date, time zone and locale.
    private static final LocalDateTime NINE = LocalDateTime.of(2030, 3, 4, 9, 0);

    private WorkspaceRepository repository;
    private Member member;
    private Resource desk;

    @BeforeEach
    void setUp() throws Exception {
        repository = TestDatabase.freshRepository();
        repository.saveMember(new Member(0, "Test Member", "", "", LocalDate.of(2030, 1, 1)));
        repository.saveResource(new Resource(0, "Test Desk", ResourceType.DESK, 1,
                new BigDecimal("8.00"), new BigDecimal("110.00"), true));
        member = repository.searchMembers("Test").getFirst();
        desk = repository.listResources(false).getFirst();
    }

    @Test
    void overlappingBookingIsRejectedByThePersistenceLayer() throws Exception {
        repository.createBooking(member.id(), desk.id(), NINE, NINE.plusHours(3));

        assertThrows(WorkspaceRepository.BookingConflictException.class,
                () -> repository.createBooking(member.id(), desk.id(), NINE.plusHours(1), NINE.plusHours(2)));
        assertThrows(WorkspaceRepository.BookingConflictException.class,
                () -> repository.createBooking(member.id(), desk.id(), NINE.minusHours(1), NINE.plusMinutes(1)));
        assertThrows(WorkspaceRepository.BookingConflictException.class,
                () -> repository.createBooking(member.id(), desk.id(), NINE, NINE.plusHours(3)));
    }

    @Test
    void adjacentBookingsAreAcceptedBeforeAndAfter() throws Exception {
        repository.createBooking(member.id(), desk.id(), NINE, NINE.plusHours(1));
        repository.createBooking(member.id(), desk.id(), NINE.plusHours(1), NINE.plusHours(2));
        repository.createBooking(member.id(), desk.id(), NINE.minusHours(1), NINE);

        assertEquals(3, repository.listBookings(NINE.toLocalDate(), "").size());
    }

    @Test
    void cancelledBookingFreesTheSlot() throws Exception {
        Booking first = repository.createBooking(member.id(), desk.id(), NINE, NINE.plusHours(1));
        repository.cancelBooking(first.id());

        Booking second = repository.createBooking(member.id(), desk.id(), NINE, NINE.plusHours(1));
        assertTrue(second.id() != first.id());
    }

    @Test
    void sameTimeOnADifferentResourceIsAllowed() throws Exception {
        repository.saveResource(new Resource(0, "Other Desk", ResourceType.DESK, 1,
                BigDecimal.ONE, BigDecimal.TEN, true));
        Resource other = repository.listResources(false).stream()
                .filter(resource -> resource.name().equals("Other Desk")).findFirst().orElseThrow();

        repository.createBooking(member.id(), desk.id(), NINE, NINE.plusHours(1));
        repository.createBooking(member.id(), other.id(), NINE, NINE.plusHours(1));
    }

    @Test
    void inactiveResourceCannotBeBooked() throws Exception {
        repository.saveResource(new Resource(desk.id(), desk.name(), desk.type(), desk.capacity(),
                desk.dailyPrice(), desk.monthlyPrice(), false));

        assertThrows(IllegalArgumentException.class,
                () -> repository.createBooking(member.id(), desk.id(), NINE, NINE.plusHours(1)));
    }

    @Test
    void concurrentBookingsForTheSameSlotAllowExactlyOne() throws Exception {
        int attempts = 8;
        ExecutorService pool = Executors.newFixedThreadPool(attempts);
        CountDownLatch go = new CountDownLatch(1);
        try {
            List<Future<Boolean>> results = new java.util.ArrayList<>();
            for (int i = 0; i < attempts; i++) {
                Callable<Boolean> task = () -> {
                    go.await();
                    try {
                        repository.createBooking(member.id(), desk.id(), NINE, NINE.plusHours(1));
                        return true;
                    } catch (WorkspaceRepository.BookingConflictException conflict) {
                        return false;
                    }
                };
                results.add(pool.submit(task));
            }
            go.countDown();
            long succeeded = 0;
            for (Future<Boolean> result : results) if (result.get()) succeeded++;
            assertEquals(1, succeeded);
        } finally {
            pool.shutdownNow();
        }
    }

    @Test
    void pricesKeepTheirExactDecimalValue() throws Exception {
        repository.saveResource(new Resource(0, "Priced Desk", ResourceType.DESK, 1,
                new BigDecimal("7.50"), new BigDecimal("95.25"), true));
        Resource priced = repository.listResources(false).stream()
                .filter(resource -> resource.name().equals("Priced Desk")).findFirst().orElseThrow();

        assertEquals(0, new BigDecimal("7.50").compareTo(priced.dailyPrice()));
        assertEquals(0, new BigDecimal("95.25").compareTo(priced.monthlyPrice()));
    }

    @Test
    void serviceUpdatesKeepAnAppendOnlyHistory() throws Exception {
        repository.updateServiceStatus("POWER", "GENERATOR", "Backup generator active");
        repository.updateServiceStatus("POWER", "OUTAGE", "Grid unavailable");

        assertEquals("OUTAGE", repository.latestServiceStatuses().stream()
                .filter(status -> status.service().equals("POWER")).findFirst().orElseThrow().state());
        assertEquals(2, repository.serviceHistory().size());
    }

    @Test
    void migrationsAreIdempotent() throws Exception {
        repository.initialize();
        repository.initialize();
        assertEquals(1, repository.searchMembers("Test").size());
    }
}
