package com.workspacehub.data;

import com.workspacehub.config.DatabaseConfig;
import org.junit.jupiter.api.Assumptions;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/**
 * Connects to a dedicated, disposable MySQL test database given by WORKSPACEHUB_TEST_DB_URL,
 * WORKSPACEHUB_TEST_DB_USER and WORKSPACEHUB_TEST_DB_PASSWORD. Every table in that database is
 * dropped before each test, so NEVER point it at real data. Tests are skipped (not passed)
 * when the variables are not set.
 */
public final class TestDatabase {
    private TestDatabase() {
    }

    /** Configuration of the test database; skips the calling test when it is not configured. */
    public static DatabaseConfig config() {
        String url = System.getenv("WORKSPACEHUB_TEST_DB_URL");
        Assumptions.assumeTrue(url != null && !url.isBlank(),
                "Set WORKSPACEHUB_TEST_DB_URL/USER/PASSWORD to run database tests (see README).");
        return new DatabaseConfig(url,
                System.getenv("WORKSPACEHUB_TEST_DB_USER"), System.getenv("WORKSPACEHUB_TEST_DB_PASSWORD"));
    }

    public static WorkspaceRepository freshRepository() throws Exception {
        DatabaseConfig config = config();
        try (Connection connection = DriverManager.getConnection(config.url(), config.user(), config.password());
             Statement statement = connection.createStatement()) {
            statement.execute("SET FOREIGN_KEY_CHECKS = 0");
            for (String table : new String[]{"booking", "service_history", "member", "resource", "schema_version"}) {
                statement.execute("DROP TABLE IF EXISTS " + table);
            }
            statement.execute("SET FOREIGN_KEY_CHECKS = 1");
        }
        WorkspaceRepository repository = new WorkspaceRepository(config);
        repository.initialize();
        return repository;
    }
}
