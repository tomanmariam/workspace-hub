package com.workspacehub.config;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;

class DatabaseConfigTest {
    @TempDir
    Path directory;

    @Test
    void environmentVariablesWin() {
        DatabaseConfig config = DatabaseConfig.load(Map.of("WORKSPACEHUB_DB_URL", "jdbc:mysql://h/db",
                "WORKSPACEHUB_DB_USER", "u", "WORKSPACEHUB_DB_PASSWORD", "p"), directory, directory);
        assertEquals("jdbc:mysql://h/db", config.url());
        assertEquals("u", config.user());
    }

    @Test
    void localPropertiesFileIsUsedWhenNoEnvironment() throws Exception {
        Files.createDirectories(directory.resolve("config"));
        Files.writeString(directory.resolve("config/local.properties"),
                "db.url=jdbc:mysql://x/y\ndb.user=a\ndb.password=b\n");
        DatabaseConfig config = DatabaseConfig.load(Map.of(), directory, directory.resolve("nohome"));
        assertEquals("a", config.user());
    }

    @Test
    void missingSettingsGiveAHelpfulMessage() {
        ConfigurationException exception = assertThrows(ConfigurationException.class,
                () -> DatabaseConfig.load(Map.of(), directory, directory.resolve("nohome")));
        assertFalse(exception.getMessage().isBlank());
    }

    @Test
    void passwordNeverAppearsInToString() {
        assertFalse(new DatabaseConfig("jdbc:mysql://h/db", "u", "s3cret-value").toString().contains("s3cret-value"));
    }
}
