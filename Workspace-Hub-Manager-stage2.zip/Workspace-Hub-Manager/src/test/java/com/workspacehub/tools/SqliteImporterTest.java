package com.workspacehub.tools;

import com.workspacehub.config.DatabaseConfig;
import com.workspacehub.data.TestDatabase;
import com.workspacehub.data.WorkspaceRepository;
import com.workspacehub.model.Booking;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class SqliteImporterTest {
    @TempDir
    Path directory;

    /** Builds a small file in the OLD SQLite layout (prices and dates stored as text). */
    private Path oldDatabase() throws SQLException {
        Path file = directory.resolve("old.db");
        try (Connection sqlite = DriverManager.getConnection("jdbc:sqlite:" + file); Statement s = sqlite.createStatement()) {
            s.executeUpdate("CREATE TABLE resource (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, type TEXT NOT NULL, capacity INTEGER NOT NULL, daily_price TEXT NOT NULL, monthly_price TEXT NOT NULL, active INTEGER NOT NULL)");
            s.executeUpdate("CREATE TABLE member (id INTEGER PRIMARY KEY AUTOINCREMENT, full_name TEXT NOT NULL, phone TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '', join_date TEXT NOT NULL)");
            s.executeUpdate("CREATE TABLE booking (id INTEGER PRIMARY KEY AUTOINCREMENT, member_id INTEGER NOT NULL, resource_id INTEGER NOT NULL, start_time TEXT NOT NULL, end_time TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL)");
            s.executeUpdate("CREATE TABLE service_history (id INTEGER PRIMARY KEY AUTOINCREMENT, service TEXT NOT NULL, state TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL)");
            s.executeUpdate("INSERT INTO resource VALUES (7, 'Old Desk', 'DESK', 1, '8', '110.5', 1), (9, 'Old Hall', 'HALL', 12, '35', '520', 0)");
            s.executeUpdate("INSERT INTO member VALUES (3, 'Old Member', '0599', 'o@x.com', '2029-12-01')");
            s.executeUpdate("INSERT INTO booking VALUES (5, 3, 7, '2030-03-04T09:00:00', '2030-03-04T10:00:00', 'ACTIVE', '2030-03-01T08:00:00'), (6, 3, 7, '2030-03-04T10:00:00', '2030-03-04T11:00:00', 'CANCELLED', '2030-03-01T08:05:00')");
            s.executeUpdate("INSERT INTO service_history VALUES (2, 'POWER', 'GENERATOR', 'Backup', '2030-03-01T07:00:00')");
        }
        return file;
    }

    @Test
    void importKeepsRowsIdsPricesAndTimes() throws Exception {
        WorkspaceRepository repository = TestDatabase.freshRepository();
        DatabaseConfig config = TestDatabase.config();
        SqliteImporter.Result result;
        try (Connection mysql = DriverManager.getConnection(config.url(), config.user(), config.password());
             Connection sqlite = SqliteImporter.openSqliteReadOnly(oldDatabase())) {
            result = SqliteImporter.importInto(mysql, sqlite, false);
        }
        assertEquals(new SqliteImporter.Result(2, 1, 2, 1), result);
        assertEquals(0, new BigDecimal("110.50").compareTo(repository.listResources(true).stream()
                .filter(r -> r.id() == 7).findFirst().orElseThrow().monthlyPrice()));
        Booking booking = repository.listBookings(LocalDate.of(2030, 3, 4), "").stream()
                .filter(b -> b.id() == 5).findFirst().orElseThrow();
        assertEquals(9, booking.startTime().getHour());
        assertEquals(3, booking.memberId());
        assertEquals(1, repository.serviceHistory().size());
    }

    @Test
    void importRefusesToMixWithExistingDataUnlessReplaceIsGiven() throws Exception {
        WorkspaceRepository repository = TestDatabase.freshRepository();
        repository.updateServiceStatus("POWER", "STABLE", "existing row");
        DatabaseConfig config = TestDatabase.config();
        Path file = oldDatabase();
        try (Connection mysql = DriverManager.getConnection(config.url(), config.user(), config.password());
             Connection sqlite = SqliteImporter.openSqliteReadOnly(file)) {
            assertThrows(SQLException.class, () -> SqliteImporter.importInto(mysql, sqlite, false));
            assertEquals(1, repository.serviceHistory().size());
            SqliteImporter.importInto(mysql, sqlite, true);
        }
        assertEquals(1, repository.serviceHistory().size());
        assertEquals("GENERATOR", repository.serviceHistory().getFirst().state());
    }

    @Test
    void failedImportChangesNothing() throws Exception {
        WorkspaceRepository repository = TestDatabase.freshRepository();
        repository.updateServiceStatus("POWER", "STABLE", "keep me");
        Path file = oldDatabase();
        try (Connection sqlite = DriverManager.getConnection("jdbc:sqlite:" + file); Statement s = sqlite.createStatement()) {
            s.executeUpdate("UPDATE resource SET daily_price = '1.239' WHERE id = 9");
        }
        DatabaseConfig config = TestDatabase.config();
        try (Connection mysql = DriverManager.getConnection(config.url(), config.user(), config.password());
             Connection sqlite = SqliteImporter.openSqliteReadOnly(file)) {
            assertThrows(SQLException.class, () -> SqliteImporter.importInto(mysql, sqlite, true));
        }
        assertEquals("STABLE", repository.serviceHistory().getFirst().state());
        assertEquals(0, repository.listResources(true).size());
    }

    @Test
    void missingSqliteFileGivesAClearError() {
        assertThrows(SQLException.class, () -> SqliteImporter.openSqliteReadOnly(directory.resolve("nope.db")));
    }
}
