package com.workspacehub.service;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class BookingRulesTest {
    private static final LocalDateTime NINE = LocalDateTime.of(2026, 11, 11, 9, 0);
    private static final LocalDateTime TEN = NINE.plusHours(1);
    private static final LocalDateTime ELEVEN = NINE.plusHours(2);

    @Test
    void overlappingIntervalsAreRejected() {
        assertTrue(BookingRules.overlaps(NINE, ELEVEN, TEN, TEN.plusHours(1)));
    }

    @Test
    void adjacentBookingsDoNotOverlap() {
        assertFalse(BookingRules.overlaps(NINE, TEN, TEN, ELEVEN));
    }

    @Test
    void separatedBookingsDoNotOverlap() {
        assertFalse(BookingRules.overlaps(NINE, TEN, ELEVEN, ELEVEN.plusHours(1)));
    }

    @Test
    void endMustBeAfterStart() {
        assertThrows(IllegalArgumentException.class, () -> BookingRules.validateInterval(TEN, NINE));
        assertThrows(IllegalArgumentException.class, () -> BookingRules.validateInterval(NINE, NINE));
    }
}
