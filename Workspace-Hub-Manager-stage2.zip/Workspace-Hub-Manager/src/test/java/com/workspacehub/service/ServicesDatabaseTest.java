package com.workspacehub.service;

import com.workspacehub.data.TestDatabase;
import com.workspacehub.data.WorkspaceRepository;
import com.workspacehub.model.Member;
import com.workspacehub.model.Resource;
import com.workspacehub.model.ResourceType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class ServicesDatabaseTest {
    private static final LocalDateTime NINE = LocalDateTime.of(2030, 3, 4, 9, 0);
    private WorkspaceRepository repository;

    @BeforeEach
    void setUp() throws Exception {
        repository = TestDatabase.freshRepository();
    }

    @Test
    void duplicateResourceNameBecomesAFieldError() throws Exception {
        ResourceService service = new ResourceService(repository);
        Resource desk = new Resource(0, "Desk Z", ResourceType.DESK, 1, BigDecimal.ONE, BigDecimal.TEN, true);
        service.save(desk);
        ValidationException error = assertThrows(ValidationException.class, () -> service.save(desk));
        assertEquals("name", error.fieldErrors().keySet().iterator().next());
    }

    @Test
    void invalidMemberIsNotSaved() throws Exception {
        MemberService service = new MemberService(repository);
        assertThrows(ValidationException.class, () -> service.save(new Member(0, " ", "", "", LocalDate.of(2030, 1, 1))));
        assertEquals(0, service.search("").size());
    }

    @Test
    void bookingServiceRejectsBadInputBeforeTouchingTheDatabase() throws Exception {
        BookingService service = new BookingService(repository);
        assertThrows(ValidationException.class, () -> service.createBooking(0, 1, NINE, NINE.plusHours(1)));
        assertThrows(ValidationException.class, () -> service.createBooking(1, 1, NINE, NINE));
        assertThrows(ValidationException.class, () -> service.createBooking(1, 1, null, NINE));
    }

    @Test
    void bookingServiceReportsAnInactiveResourceAsAValidationProblem() throws Exception {
        new MemberService(repository).save(new Member(0, "M", "", "", LocalDate.of(2030, 1, 1)));
        ResourceService resources = new ResourceService(repository);
        resources.save(new Resource(0, "Off desk", ResourceType.DESK, 1, BigDecimal.ONE, BigDecimal.TEN, false));
        long memberId = repository.searchMembers("").getFirst().id();
        long resourceId = resources.list(true).getFirst().id();
        assertThrows(ValidationException.class,
                () -> new BookingService(repository).createBooking(memberId, resourceId, NINE, NINE.plusHours(1)));
    }
}
