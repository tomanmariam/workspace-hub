package com.workspacehub.service;

import com.workspacehub.model.Member;
import com.workspacehub.model.Resource;
import com.workspacehub.model.ResourceType;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ValidatorsTest {
    private static Resource resource(String name, int capacity, String daily, String monthly) {
        return new Resource(0, name, ResourceType.DESK, capacity, new BigDecimal(daily), new BigDecimal(monthly), true);
    }

    private static Member member(String name, String phone, String email) {
        return new Member(0, name, phone, email, LocalDate.of(2030, 1, 1));
    }

    @Test
    void validResourceIsAccepted() {
        assertDoesNotThrow(() -> ResourceValidator.validate(resource("Desk A-01", 1, "8", "110.50")));
        assertDoesNotThrow(() -> ResourceValidator.validate(resource("Free desk", 1, "0", "0")));
    }

    @Test
    void resourceErrorsAreReportedPerField() {
        ValidationException error = assertThrows(ValidationException.class,
                () -> ResourceValidator.validate(resource("  ", 0, "-1", "1.234")));
        assertEquals(java.util.Set.of("name", "capacity", "dailyPrice", "monthlyPrice"), error.fieldErrors().keySet());
    }

    @Test
    void resourceNameLengthAndPriceLimitsMatchTheDatabase() {
        assertThrows(ValidationException.class,
                () -> ResourceValidator.validate(resource("x".repeat(101), 1, "1", "1")));
        assertDoesNotThrow(() -> ResourceValidator.validate(resource("x".repeat(100), 1, "1", "1")));
        assertThrows(ValidationException.class,
                () -> ResourceValidator.validate(resource("Big", 1, "10000000000", "1")));
    }

    @Test
    void validMemberIsAccepted() {
        assertDoesNotThrow(() -> MemberValidator.validate(member("Sample Person", "+970 59 123 4567", "a@b.co")));
        assertDoesNotThrow(() -> MemberValidator.validate(member("Only Name", "", "")));
    }

    @Test
    void memberErrorsAreReportedPerField() {
        ValidationException error = assertThrows(ValidationException.class,
                () -> MemberValidator.validate(member("", "abc", "not-an-email")));
        assertEquals(java.util.Set.of("fullName", "phone", "email"), error.fieldErrors().keySet());
        assertTrue(error.getMessage().contains("full name"));
    }

    @Test
    void emailShapeIsChecked() {
        for (String bad : new String[]{"a@b", "@b.com", "a@@b.com", "a b@c.com", "a@b."}) {
            assertThrows(ValidationException.class, () -> MemberValidator.validate(member("N", "", bad)), bad);
        }
    }
}
