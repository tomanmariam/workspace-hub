# Workspace Hub Manager — Implementation Plan

## Product scope

Build a local-first Java desktop application for staff managing one shared workspace. Follow the uploaded report's JavaFX and layered design, and the public University-System example's Java/Maven/MVC and relational persistence approach without copying its student-registration domain. The first working slice covers a dashboard, desks and halls, members, bookings with overlap prevention, and manually updated power/internet status. Cafeteria stock/orders, payments/subscriptions, reports/CSV export, and role-based login remain subsequent outcomes, not claims about this first slice.

## Architecture and stack

Use Java 21, JavaFX controls, Maven, SQLite via JDBC, and JUnit 5. Keep the interface in `ui`, domain records in `model`, business rules in `service`, JDBC schema/queries in `data`, and small shared helpers in `util`. Keep JavaFX components out of the booking service so its rules remain independently verifiable. Use SQLite transactions for booking creation; treat a booking as conflicting when an existing non-cancelled booking for the same resource satisfies `existing.start < requested.end && existing.end > requested.start`. Persist to an application data directory outside the source tree so ordinary launches retain data without requiring internet or a preinstalled server.

## Project structure

- `src/main/java/com/workspacehub/WorkspaceHubApplication.java`: JavaFX entry point and lifecycle.
- `src/main/java/com/workspacehub/ui/`: application shell, navigation, and first-pass screens/forms.
- `src/main/java/com/workspacehub/model/`: resources, members, bookings, service status, and enums/value types.
- `src/main/java/com/workspacehub/service/`: booking conflict logic and dashboard/business operations.
- `src/main/java/com/workspacehub/data/`: SQLite connection, schema initialization, and repository/DAO operations.
- `src/main/resources/`: CSS theme and optional assets.
- `src/test/java/`: JUnit tests for business rules.
- `README.md`, `TODO.md`: setup and staged progress.

## Design direction

Use a calm operations-console aesthetic for reception and workspace managers: warm off-white work surfaces, deep ink/navy navigation, and a distinctive teal accent. Keep density moderate, tables readable, status visible without color alone, and common actions near the data they affect. Use a persistent left navigation rail, a concise top bar, and dashboard cards that prioritize availability, today's bookings, and power/internet status. Use restrained transitions only for navigation and feedback; no motion should delay data entry.

Brand essence: a dependable, clear operations desk for a small shared workspace; practical, composed, local-first. Brand voice is direct and staff-oriented: “See today's availability at a glance.” / “A booking is saved only when the time slot is clear.” The wordmark pairs a compact W monogram on a rounded teal tile with the Workspace Hub name. Signature brand color: teal.

## Delivery boundaries

This is a desktop application, not a website. Do not deploy or publish it. The first iteration does not add online payments, device-driven monitoring, multi-branch support, or a member self-service portal. Avoid real user data in starter records. Provide source, local run instructions, and a packaged archive when implementation is ready.
