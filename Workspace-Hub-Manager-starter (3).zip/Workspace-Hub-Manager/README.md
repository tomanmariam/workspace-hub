# Workspace Hub Manager

A local-first Java desktop application for shared-workspace staff. This starter is based on the requirements in `Graduation_Project_Report_Full.docx` and uses a layered Java/MVC structure inspired by the provided University-System example, while keeping this project’s own domain and features.

## First working slice

The current build includes a dashboard, desk/hall inventory, member records, booking creation and cancellation, overlap prevention, and manually updated power/internet statuses with a timestamped history. Booking logic is isolated from JavaFX and tested with JUnit. Cafeteria, subscriptions/payments, management reports/CSV, and login/roles are staged in `TODO.md` and are not yet implemented.

The first run seeds clearly labelled sample members, resources, bookings, and service statuses. Data is stored locally at `~/.workspace-hub-manager/workspace-hub.db`; deleting that file resets the sample database. No internet connection or MySQL server is needed to run this local starter.

## Requirements

- JDK 21
- A desktop environment that supports JavaFX

## Run

```bash
./mvnw clean test
./mvnw javafx:run
```

The wrapper downloads its pinned Maven version the first time it runs. On Windows, use `mvnw.cmd`. To use a different local SQLite file, pass `-Dworkspacehub.db=/absolute/path/to/workspace-hub.db` to the Java process.

## Structure

- `model` — workspace resources, members, bookings, and service status.
- `data` — SQLite schema, repository queries, transaction handling, and sample data.
- `service` — business rules such as time interval validation and overlap checks.
- `ui` — JavaFX application shell, dashboard, and operations screens.
- `src/test` — focused unit tests for booking time rules.

## Notes

Rates are displayed without a currency symbol because the report does not specify a currency. Service status is entered by staff; the app does not read sensors. The first iteration is a desktop MVP, not a web or mobile system.
