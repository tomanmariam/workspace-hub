package com.workspacehub.data;

import com.workspacehub.model.Booking;
import com.workspacehub.model.Member;
import com.workspacehub.model.Resource;
import com.workspacehub.model.ResourceType;
import com.workspacehub.model.ServiceStatus;
import com.workspacehub.service.BookingRules;

import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public final class WorkspaceRepository {
    private static final DateTimeFormatter DATE_TIME_FORMAT = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
    private final Path databaseFile;
    private final String jdbcUrl;

    public WorkspaceRepository() throws Exception {
        this(defaultDatabaseFile());
    }

    private static Path defaultDatabaseFile() {
        String configuredPath = System.getProperty("workspacehub.db");
        return configuredPath == null || configuredPath.isBlank()
                ? Path.of(System.getProperty("user.home"), ".workspace-hub-manager", "workspace-hub.db")
                : Path.of(configuredPath);
    }

    public WorkspaceRepository(Path databaseFile) throws Exception {
        this.databaseFile = databaseFile.toAbsolutePath();
        Files.createDirectories(this.databaseFile.getParent());
        jdbcUrl = "jdbc:sqlite:" + this.databaseFile;
    }

    public Path databaseFile() {
        return databaseFile;
    }

    private Connection connect() throws SQLException {
        Connection connection = DriverManager.getConnection(jdbcUrl);
        try (Statement statement = connection.createStatement()) {
            statement.execute("PRAGMA foreign_keys = ON");
            statement.execute("PRAGMA busy_timeout = 5000");
        }
        return connection;
    }

    public void initialize() throws SQLException {
        try (Connection connection = connect(); Statement statement = connection.createStatement()) {
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS resource (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT NOT NULL UNIQUE,
                        type TEXT NOT NULL CHECK (type IN ('DESK', 'HALL')),
                        capacity INTEGER NOT NULL DEFAULT 1 CHECK (capacity > 0),
                        daily_price TEXT NOT NULL DEFAULT '0',
                        monthly_price TEXT NOT NULL DEFAULT '0',
                        active INTEGER NOT NULL DEFAULT 1
                    )
                    """);
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS member (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        full_name TEXT NOT NULL,
                        phone TEXT NOT NULL DEFAULT '',
                        email TEXT NOT NULL DEFAULT '',
                        join_date TEXT NOT NULL
                    )
                    """);
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS booking (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        member_id INTEGER NOT NULL REFERENCES member(id),
                        resource_id INTEGER NOT NULL REFERENCES resource(id),
                        start_time TEXT NOT NULL,
                        end_time TEXT NOT NULL,
                        status TEXT NOT NULL DEFAULT 'ACTIVE'
                            CHECK (status IN ('ACTIVE', 'CANCELLED')),
                        created_at TEXT NOT NULL
                    )
                    """);
            statement.executeUpdate("CREATE INDEX IF NOT EXISTS idx_booking_resource_period "
                    + "ON booking(resource_id, status, start_time, end_time)");
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS service_history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        service TEXT NOT NULL CHECK (service IN ('POWER', 'INTERNET')),
                        state TEXT NOT NULL,
                        detail TEXT NOT NULL DEFAULT '',
                        updated_at TEXT NOT NULL
                    )
                    """);
        }
        seedDemoData();
    }

    private void seedDemoData() throws SQLException {
        try (Connection connection = connect()) {
            if (count(connection, "resource") == 0) {
                try (PreparedStatement insert = connection.prepareStatement("""
                        INSERT INTO resource(name, type, capacity, daily_price, monthly_price, active)
                        VALUES(?, ?, ?, ?, ?, 1)
                        """)) {
                    addResource(insert, "Desk A-01", "DESK", 1, "8", "110");
                    addResource(insert, "Desk A-02", "DESK", 1, "8", "110");
                    addResource(insert, "Desk A-03", "DESK", 1, "8", "110");
                    addResource(insert, "Desk B-01", "DESK", 1, "7", "95");
                    addResource(insert, "Focus Room", "HALL", 4, "18", "260");
                    addResource(insert, "Workshop Hall", "HALL", 12, "35", "520");
                    insert.executeBatch();
                }
            }
            if (count(connection, "member") == 0) {
                try (PreparedStatement insert = connection.prepareStatement("""
                        INSERT INTO member(full_name, phone, email, join_date) VALUES(?, '', '', ?)
                        """)) {
                    LocalDate today = LocalDate.now();
                    for (int index = 1; index <= 4; index++) {
                        insert.setString(1, String.format("Sample member %02d", index));
                        insert.setString(2, today.minusDays(index * 3L).toString());
                        insert.addBatch();
                    }
                    insert.executeBatch();
                }
            }
            if (count(connection, "service_history") == 0) {
                insertService(connection, "POWER", "GENERATOR", "Backup generator active");
                insertService(connection, "INTERNET", "STABLE", "Speed not yet measured");
            }
            if (count(connection, "booking") == 0) {
                long memberId = firstId(connection, "member");
                long resourceId = firstId(connection, "resource");
                LocalDate today = LocalDate.now();
                insertBooking(connection, memberId, resourceId,
                        today.atTime(9, 0), today.atTime(12, 0));
                Long secondResource = secondId(connection, "resource");
                if (secondResource != null) {
                    insertBooking(connection, memberId, secondResource,
                            today.atTime(13, 0), today.atTime(16, 0));
                }
            }
        }
    }

    private static void addResource(PreparedStatement insert, String name, String type,
                                    int capacity, String daily, String monthly) throws SQLException {
        insert.setString(1, name);
        insert.setString(2, type);
        insert.setInt(3, capacity);
        insert.setString(4, daily);
        insert.setString(5, monthly);
        insert.addBatch();
    }

    private static long count(Connection connection, String table) throws SQLException {
        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery("SELECT COUNT(*) FROM " + table)) {
            return result.next() ? result.getLong(1) : 0;
        }
    }

    private static long firstId(Connection connection, String table) throws SQLException {
        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery("SELECT id FROM " + table + " ORDER BY id LIMIT 1")) {
            if (!result.next()) throw new SQLException("Cannot seed demo booking: no " + table + " rows.");
            return result.getLong(1);
        }
    }

    private static Long secondId(Connection connection, String table) throws SQLException {
        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery("SELECT id FROM " + table + " ORDER BY id LIMIT 1 OFFSET 1")) {
            return result.next() ? result.getLong(1) : null;
        }
    }

    private static void insertBooking(Connection connection, long memberId, long resourceId,
                                      LocalDateTime start, LocalDateTime end) throws SQLException {
        try (PreparedStatement insert = connection.prepareStatement("""
                INSERT INTO booking(member_id, resource_id, start_time, end_time, status, created_at)
                VALUES(?, ?, ?, ?, 'ACTIVE', ?)
                """)) {
            insert.setLong(1, memberId);
            insert.setLong(2, resourceId);
            insert.setString(3, format(start));
            insert.setString(4, format(end));
            insert.setString(5, format(LocalDateTime.now()));
            insert.executeUpdate();
        }
    }

    private static void insertService(Connection connection, String service, String state, String detail)
            throws SQLException {
        try (PreparedStatement insert = connection.prepareStatement("""
                INSERT INTO service_history(service, state, detail, updated_at) VALUES(?, ?, ?, ?)
                """)) {
            insert.setString(1, service);
            insert.setString(2, state);
            insert.setString(3, detail);
            insert.setString(4, format(LocalDateTime.now()));
            insert.executeUpdate();
        }
    }

    public List<Resource> listResources(boolean includeInactive) throws SQLException {
        String sql = "SELECT * FROM resource " + (includeInactive ? "" : "WHERE active = 1 ")
                + "ORDER BY CASE type WHEN 'DESK' THEN 0 ELSE 1 END, name COLLATE NOCASE";
        try (Connection connection = connect(); PreparedStatement query = connection.prepareStatement(sql);
             ResultSet result = query.executeQuery()) {
            List<Resource> resources = new ArrayList<>();
            while (result.next()) resources.add(readResource(result));
            return resources;
        }
    }

    public void saveResource(Resource resource) throws SQLException {
        String sql = resource.id() == 0
                ? "INSERT INTO resource(name, type, capacity, daily_price, monthly_price, active) VALUES(?, ?, ?, ?, ?, ?)"
                : "UPDATE resource SET name = ?, type = ?, capacity = ?, daily_price = ?, monthly_price = ?, active = ? WHERE id = ?";
        try (Connection connection = connect(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, resource.name().trim());
            statement.setString(2, resource.type().name());
            statement.setInt(3, resource.capacity());
            statement.setString(4, resource.dailyPrice().toPlainString());
            statement.setString(5, resource.monthlyPrice().toPlainString());
            statement.setInt(6, resource.active() ? 1 : 0);
            if (resource.id() != 0) statement.setLong(7, resource.id());
            statement.executeUpdate();
        }
    }

    public List<Member> searchMembers(String search) throws SQLException {
        String filter = search == null ? "" : search.trim();
        String pattern = "%" + filter + "%";
        try (Connection connection = connect(); PreparedStatement query = connection.prepareStatement("""
                SELECT * FROM member
                WHERE full_name LIKE ? OR phone LIKE ? OR email LIKE ?
                ORDER BY full_name COLLATE NOCASE
                """)) {
            query.setString(1, pattern);
            query.setString(2, pattern);
            query.setString(3, pattern);
            try (ResultSet result = query.executeQuery()) {
                List<Member> members = new ArrayList<>();
                while (result.next()) members.add(readMember(result));
                return members;
            }
        }
    }

    public void saveMember(Member member) throws SQLException {
        String sql = member.id() == 0
                ? "INSERT INTO member(full_name, phone, email, join_date) VALUES(?, ?, ?, ?)"
                : "UPDATE member SET full_name = ?, phone = ?, email = ? WHERE id = ?";
        try (Connection connection = connect(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, member.fullName().trim());
            statement.setString(2, member.phone() == null ? "" : member.phone().trim());
            statement.setString(3, member.email() == null ? "" : member.email().trim());
            if (member.id() == 0) statement.setString(4, member.joinDate().toString());
            else statement.setLong(4, member.id());
            statement.executeUpdate();
        }
    }

    public List<Booking> listBookings(LocalDate dateFilter, String search) throws SQLException {
        String term = search == null ? "" : search.trim();
        StringBuilder sql = new StringBuilder("""
                SELECT b.id, b.member_id, m.full_name AS member_name, b.resource_id,
                       r.name AS resource_name, b.start_time, b.end_time, b.status
                FROM booking b
                JOIN member m ON m.id = b.member_id
                JOIN resource r ON r.id = b.resource_id
                WHERE 1 = 1
                """);
        if (dateFilter != null) sql.append(" AND b.start_time >= ? AND b.start_time < ? ");
        sql.append(" AND (m.full_name LIKE ? OR r.name LIKE ? OR b.status LIKE ?) ");
        sql.append(" ORDER BY b.start_time DESC, b.id DESC");
        try (Connection connection = connect(); PreparedStatement query = connection.prepareStatement(sql.toString())) {
            int index = 1;
            if (dateFilter != null) {
                query.setString(index++, dateFilter.atStartOfDay().format(DATE_TIME_FORMAT));
                query.setString(index++, dateFilter.plusDays(1).atStartOfDay().format(DATE_TIME_FORMAT));
            }
            String pattern = "%" + term + "%";
            query.setString(index++, pattern);
            query.setString(index++, pattern);
            query.setString(index, pattern);
            try (ResultSet result = query.executeQuery()) {
                List<Booking> bookings = new ArrayList<>();
                while (result.next()) bookings.add(readBooking(result));
                return bookings;
            }
        }
    }

    public Booking createBooking(long memberId, long resourceId, LocalDateTime start, LocalDateTime end)
            throws SQLException, BookingConflictException {
        BookingRules.validateInterval(start, end);
        String formattedStart = format(start);
        String formattedEnd = format(end);
        try (Connection connection = connect()) {
            connection.setAutoCommit(false);
            try {
                try (PreparedStatement conflict = connection.prepareStatement("""
                        SELECT 1 FROM booking
                        WHERE resource_id = ? AND status <> 'CANCELLED'
                          AND start_time < ? AND end_time > ?
                        LIMIT 1
                        """)) {
                    conflict.setLong(1, resourceId);
                    conflict.setString(2, formattedEnd);
                    conflict.setString(3, formattedStart);
                    try (ResultSet result = conflict.executeQuery()) {
                        if (result.next()) throw new BookingConflictException(
                                "That desk or hall is already booked during the selected time.");
                    }
                }
                try (PreparedStatement insert = connection.prepareStatement("""
                        INSERT INTO booking(member_id, resource_id, start_time, end_time, status, created_at)
                        VALUES(?, ?, ?, ?, 'ACTIVE', ?)
                        """)) {
                    insert.setLong(1, memberId);
                    insert.setLong(2, resourceId);
                    insert.setString(3, formattedStart);
                    insert.setString(4, formattedEnd);
                    insert.setString(5, format(LocalDateTime.now()));
                    insert.executeUpdate();
                }
                connection.commit();
            } catch (SQLException | RuntimeException | BookingConflictException exception) {
                connection.rollback();
                throw exception;
            }
        }
        return listBookings(null, "").stream()
                .filter(booking -> booking.memberId() == memberId && booking.resourceId() == resourceId
                        && booking.startTime().equals(start) && booking.endTime().equals(end))
                .findFirst().orElseThrow(() -> new SQLException("Booking was saved but could not be reloaded."));
    }

    public void cancelBooking(long bookingId) throws SQLException {
        try (Connection connection = connect(); PreparedStatement update = connection.prepareStatement(
                "UPDATE booking SET status = 'CANCELLED' WHERE id = ? AND status = 'ACTIVE'")) {
            update.setLong(1, bookingId);
            update.executeUpdate();
        }
    }

    public long countActiveResources() throws SQLException {
        return scalarLong("SELECT COUNT(*) FROM resource WHERE active = 1");
    }

    public long countMembers() throws SQLException {
        return scalarLong("SELECT COUNT(*) FROM member");
    }

    public long countBookingsOn(LocalDate date) throws SQLException {
        try (Connection connection = connect(); PreparedStatement query = connection.prepareStatement(
                "SELECT COUNT(*) FROM booking WHERE status = 'ACTIVE' AND start_time >= ? AND start_time < ?")) {
            query.setString(1, date.atStartOfDay().format(DATE_TIME_FORMAT));
            query.setString(2, date.plusDays(1).atStartOfDay().format(DATE_TIME_FORMAT));
            try (ResultSet result = query.executeQuery()) {
                return result.next() ? result.getLong(1) : 0;
            }
        }
    }

    public long countAvailableNow() throws SQLException {
        LocalDateTime now = LocalDateTime.now();
        try (Connection connection = connect(); PreparedStatement query = connection.prepareStatement("""
                SELECT COUNT(*) FROM resource r
                WHERE r.active = 1 AND NOT EXISTS (
                    SELECT 1 FROM booking b WHERE b.resource_id = r.id AND b.status = 'ACTIVE'
                      AND b.start_time <= ? AND b.end_time > ?
                )
                """)) {
            query.setString(1, format(now));
            query.setString(2, format(now));
            try (ResultSet result = query.executeQuery()) {
                return result.next() ? result.getLong(1) : 0;
            }
        }
    }

    public Set<Long> bookedResourceIdsNow() throws SQLException {
        String now = format(LocalDateTime.now());
        try (Connection connection = connect(); PreparedStatement query = connection.prepareStatement("""
                SELECT DISTINCT resource_id FROM booking
                WHERE status = 'ACTIVE' AND start_time <= ? AND end_time > ?
                """)) {
            query.setString(1, now);
            query.setString(2, now);
            try (ResultSet result = query.executeQuery()) {
                Set<Long> booked = new HashSet<>();
                while (result.next()) booked.add(result.getLong(1));
                return booked;
            }
        }
    }

    public List<ServiceStatus> latestServiceStatuses() throws SQLException {
        try (Connection connection = connect(); PreparedStatement query = connection.prepareStatement("""
                SELECT h.service, h.state, h.detail, h.updated_at
                FROM service_history h
                WHERE h.id = (SELECT h2.id FROM service_history h2
                              WHERE h2.service = h.service ORDER BY h2.updated_at DESC, h2.id DESC LIMIT 1)
                ORDER BY h.service
                """); ResultSet result = query.executeQuery()) {
            List<ServiceStatus> statuses = new ArrayList<>();
            while (result.next()) statuses.add(new ServiceStatus(result.getString("service"),
                    result.getString("state"), result.getString("detail"),
                    LocalDateTime.parse(result.getString("updated_at"), DATE_TIME_FORMAT)));
            return statuses;
        }
    }

    public List<ServiceStatus> serviceHistory() throws SQLException {
        try (Connection connection = connect(); PreparedStatement query = connection.prepareStatement("""
                SELECT service, state, detail, updated_at
                FROM service_history
                ORDER BY updated_at DESC, id DESC
                LIMIT 100
                """); ResultSet result = query.executeQuery()) {
            List<ServiceStatus> history = new ArrayList<>();
            while (result.next()) history.add(new ServiceStatus(result.getString("service"),
                    result.getString("state"), result.getString("detail"),
                    LocalDateTime.parse(result.getString("updated_at"), DATE_TIME_FORMAT)));
            return history;
        }
    }

    public void updateServiceStatus(String service, String state, String detail) throws SQLException {
        if (!List.of("POWER", "INTERNET").contains(service)) throw new IllegalArgumentException("Unknown service.");
        try (Connection connection = connect()) {
            insertService(connection, service, state, detail == null ? "" : detail.trim());
        }
    }

    private long scalarLong(String sql) throws SQLException {
        try (Connection connection = connect(); Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery(sql)) {
            return result.next() ? result.getLong(1) : 0;
        }
    }

    private static Resource readResource(ResultSet result) throws SQLException {
        return new Resource(result.getLong("id"), result.getString("name"),
                ResourceType.valueOf(result.getString("type")), result.getInt("capacity"),
                new BigDecimal(result.getString("daily_price")),
                new BigDecimal(result.getString("monthly_price")), result.getInt("active") == 1);
    }

    private static Member readMember(ResultSet result) throws SQLException {
        return new Member(result.getLong("id"), result.getString("full_name"),
                result.getString("phone"), result.getString("email"),
                LocalDate.parse(result.getString("join_date")));
    }

    private static Booking readBooking(ResultSet result) throws SQLException {
        return new Booking(result.getLong("id"), result.getLong("member_id"),
                result.getString("member_name"), result.getLong("resource_id"),
                result.getString("resource_name"), LocalDateTime.parse(result.getString("start_time"), DATE_TIME_FORMAT),
                LocalDateTime.parse(result.getString("end_time"), DATE_TIME_FORMAT), result.getString("status"));
    }

    private static String format(LocalDateTime value) {
        return value.withNano(0).format(DATE_TIME_FORMAT);
    }

    public static final class BookingConflictException extends Exception {
        public BookingConflictException(String message) {
            super(message);
        }
    }
}
