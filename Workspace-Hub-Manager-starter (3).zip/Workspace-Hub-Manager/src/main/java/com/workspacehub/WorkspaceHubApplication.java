package com.workspacehub;

import com.workspacehub.data.WorkspaceRepository;
import com.workspacehub.ui.MainController;
import javafx.application.Application;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

public class WorkspaceHubApplication extends Application {
    @Override
    public void start(Stage stage) {
        try {
            WorkspaceRepository repository = new WorkspaceRepository();
            repository.initialize();
            new MainController(stage, repository).show();
        } catch (Exception exception) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Workspace Hub Manager");
            alert.setHeaderText("The local workspace database could not be opened");
            alert.setContentText(exception.getMessage());
            alert.showAndWait();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
