package com.workspacehub.service;

import com.workspacehub.data.WorkspaceRepository;
import com.workspacehub.data.WorkspaceRepository.BookingConflictException;
import com.workspacehub.model.Booking;

import java.sql.SQLException;
import java.time.LocalDateTime;

public final class BookingService {
    private final WorkspaceRepository repository;

    public BookingService(WorkspaceRepository repository) {
        this.repository = repository;
    }

    public Booking createBooking(long memberId, long resourceId,
                                 LocalDateTime start, LocalDateTime end)
            throws SQLException, BookingConflictException {
        BookingRules.validateInterval(start, end);
        return repository.createBooking(memberId, resourceId, start, end);
    }

    public void cancelBooking(long bookingId) throws SQLException {
        repository.cancelBooking(bookingId);
    }
}
