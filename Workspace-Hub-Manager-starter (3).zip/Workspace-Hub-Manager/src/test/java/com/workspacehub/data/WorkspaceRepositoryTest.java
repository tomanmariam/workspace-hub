package com.workspacehub.data;

import com.workspacehub.model.Member;
import com.workspacehub.model.Resource;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class WorkspaceRepositoryTest {
    @TempDir
    Path temporaryDirectory;

    @Test
    void overlappingBookingIsRejectedByTheDatabaseRepository() throws Exception {
        WorkspaceRepository repository = new WorkspaceRepository(temporaryDirectory.resolve("test.db"));
        repository.initialize();
        Member member = repository.searchMembers("").getFirst();
        Resource resource = repository.listResources(false).getFirst();
        LocalDate today = LocalDate.now();

        assertThrows(WorkspaceRepository.BookingConflictException.class,
                () -> repository.createBooking(member.id(), resource.id(),
                        today.atTime(10, 0), today.atTime(11, 0)));
    }

    @Test
    void adjacentBookingIsAcceptedAndPersistsAfterReopening() throws Exception {
        Path file = temporaryDirectory.resolve("test.db");
        WorkspaceRepository repository = new WorkspaceRepository(file);
        repository.initialize();
        Member member = repository.searchMembers("").getFirst();
        Resource resource = repository.listResources(false).getFirst();
        LocalDateTime start = LocalDate.now().atTime(12, 0);
        LocalDateTime end = start.plusHours(1);

        repository.createBooking(member.id(), resource.id(), start, end);
        WorkspaceRepository reopened = new WorkspaceRepository(file);
        reopened.initialize();

        assertEquals(1, reopened.listBookings(LocalDate.now(), "Sample member 01").stream()
                .filter(booking -> booking.startTime().equals(start) && booking.endTime().equals(end))
                .count());
    }

    @Test
    void serviceUpdatesKeepAnAppendOnlyHistory() throws Exception {
        WorkspaceRepository repository = new WorkspaceRepository(temporaryDirectory.resolve("services.db"));
        repository.initialize();
        repository.updateServiceStatus("POWER", "OUTAGE", "Grid unavailable");

        assertEquals("OUTAGE", repository.latestServiceStatuses().stream()
                .filter(status -> status.service().equals("POWER")).findFirst().orElseThrow().state());
        assertEquals(3, repository.serviceHistory().size());
    }
}
